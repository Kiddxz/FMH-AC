<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
destroy_secure_session();
header('Location: login.php');
exit;
