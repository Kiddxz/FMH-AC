<?php
// Private local configuration. Do not share this file or the configured ZIP.
return [
    'gmail_user' => 'supremedentc@gmail.com',
    'gmail_app_password' => 'PASTE_YOUR_16_CHARACTER_GMAIL_APP_PASSWORD',
    'smtp_port' => 'auto',
    'log_otp' => false,
];
