<?php
/**
 * SupremeDent local SMS settings (this file is excluded by .gitignore).
 *
 * Patient contact-number OTPs are sent through IPROG SMS (https://sms.iprogtech.com).
 * The token below is the clinic's IPROG "Main API token" (Dashboard > API access).
 * Each SMS uses IPROG credits, so keep credits loaded on the IPROG account.
 */
return [
    'provider' => 'iprog',
    'iprog_api_token' => 'PASTE_YOUR_IPROG_API_TOKEN_HERE',
    // true = write OTPs to storage/otp.log instead of sending a real SMS (local testing only).
    'log_only' => false,

    // Optional Infobip fallback (set 'provider' => 'infobip' to use it).
    'api_key' => 'PASTE_YOUR_INFOBIP_API_KEY_HERE',
    'base_url' => 'm9kxgj.api.infobip.com',
    'sender' => 'ServiceSMS',
];
