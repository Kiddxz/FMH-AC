<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$message = '';
$wrongPassword = false;
$lockSeconds = 0;
$emailValue = strtolower(trim($_POST['login_email'] ?? ''));

/*
 * Sign-in lockout: 5 wrong attempts lock the email for 5 minutes. After a lockout ends,
 * the next wrong password locks it again for 10 minutes. A successful sign-in clears it.
 */
const LOGIN_MAX_ATTEMPTS = 5;
function login_attempt_state(mysqli $conn, string $email): array
{
    $st = $conn->prepare('SELECT failed_count,lock_level,UNIX_TIMESTAMP(locked_until) locked_ts,UNIX_TIMESTAMP(last_failed_at) last_ts FROM login_attempts WHERE email=? LIMIT 1');
    $st->bind_param('s', $email);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();
    $state = ['failed' => (int)($row['failed_count'] ?? 0), 'level' => (int)($row['lock_level'] ?? 0), 'locked_ts' => (int)($row['locked_ts'] ?? 0)];
    // Forget old history after a quiet day.
    if ($row && (int)$row['last_ts'] > 0 && (int)$row['last_ts'] < time() - 86400 && $state['locked_ts'] < time()) $state = ['failed' => 0, 'level' => 0, 'locked_ts' => 0];
    return $state;
}
function login_attempt_failed(mysqli $conn, string $email, array $state): array
{
    $failed = $state['failed'] + 1;
    $level = $state['level'];
    $lockedUntil = null;
    if ($level >= 1 || $failed >= LOGIN_MAX_ATTEMPTS) {
        $level = min(9, $level + 1);
        $minutes = $level >= 2 ? 10 : 5;
        $lockedUntil = date('Y-m-d H:i:s', time() + $minutes * 60);
        $failed = 0;
    }
    $ip = client_ip();
    $st = $conn->prepare('INSERT INTO login_attempts(email,failed_count,lock_level,locked_until,last_failed_at,last_ip) VALUES(?,?,?,?,NOW(),?) ON DUPLICATE KEY UPDATE failed_count=VALUES(failed_count),lock_level=VALUES(lock_level),locked_until=VALUES(locked_until),last_failed_at=NOW(),last_ip=VALUES(last_ip)');
    $st->bind_param('siiss', $email, $failed, $level, $lockedUntil, $ip);
    $st->execute();
    $st->close();
    return ['failed' => $failed, 'level' => $level, 'locked_ts' => $lockedUntil ? strtotime($lockedUntil) : 0];
}
function login_attempt_clear(mysqli $conn, string $email): void
{
    $st = $conn->prepare('DELETE FROM login_attempts WHERE email=?');
    $st->bind_param('s', $email);
    $st->execute();
    $st->close();
}
function login_lock_message(int $seconds): string
{
    $m = intdiv($seconds, 60);
    $s = $seconds % 60;
    return 'Too many failed sign-in attempts. Please wait ' . $m . ':' . str_pad((string)$s, 2, '0', STR_PAD_LEFT) . ' before trying again.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $emailValue;
    $password = (string)($_POST['login_password'] ?? '');

    if (!csrf_valid($_POST['csrf_token'] ?? null)) {
        $message = 'Your session expired. Refresh the page and try again.';
    } elseif (!valid_email_address($email)) {
        $message = 'Enter a valid email address.';
    } elseif ($password === '') {
        $message = 'Enter your password.';
    } elseif (($attempt = login_attempt_state($conn, $email)) && $attempt['locked_ts'] > time()) {
        $lockSeconds = $attempt['locked_ts'] - time();
        $message = login_lock_message($lockSeconds);
    } else {
        $stmt = $conn->prepare("SELECT id,first_name,last_name,email,password,role,status FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $badEmail = !$user || $user['status'] !== 'active';
        if ($badEmail || !password_verify($password, $user['password'])) {
            usleep(250000);
            $attempt = login_attempt_failed($conn, $email, $attempt);
            if ($attempt['locked_ts'] > time()) {
                $lockSeconds = $attempt['locked_ts'] - time();
                $message = login_lock_message($lockSeconds);
                if ($user) log_activity($conn, (int)$user['id'], 'Sign-in locked', 'Authentication', 'Locked for ' . ceil($lockSeconds / 60) . ' minutes after failed attempts');
            } else {
                $left = LOGIN_MAX_ATTEMPTS - $attempt['failed'];
                $message = ($badEmail ? "The email address that you've entered isn't connected to an account." : "The password that you've entered is incorrect.")
                    . ' ' . $left . ' attempt' . ($left === 1 ? '' : 's') . ' remaining.';
                $wrongPassword = !$badEmail;
            }
        } else {
            login_attempt_clear($conn, $email);
            // Each role signs in to its own portal session, so a patient, assistant, dentist and super admin
            // can all stay signed in at the same time in one browser.
            // A half-finished password reset in this browser is dropped once someone signs in.
            unset($_SESSION['reset_user_id'], $_SESSION['reset_verified_at']);
            if (in_array($user['role'], SUPREMEDENT_PORTALS, true)) switch_to_portal_session($user['role']);
            else session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            $_SESSION['session_regenerated_at'] = time();
            log_activity($conn, (int)$user['id'], 'Signed in', 'Authentication', 'Role: '.$user['role']);

            $destinations = [
                'patient'=>'../patient/dashboard.php',
                'assistant'=>'../assistant/dashboard.php',
                'dentist'=>'../dentist/dashboard.php',
                'superadmin'=>'../superadmin/dashboard.php',
            ];
            if (isset($destinations[$user['role']])) {
                header('Location: '.$destinations[$user['role']]);
                exit;
            }
            session_destroy();
            $message = 'Invalid user role.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><meta name="description" content="Sign in securely to SupremeDent.">
<title>Log In | SupremeDent</title>
<link rel="stylesheet" href="../assets/css/styles.css"><link rel="stylesheet" href="../assets/css/app.css"><link rel="stylesheet" href="../assets/css/revamp.css"><link rel="stylesheet" href="../assets/css/ui_fixes.css"><link rel="stylesheet" href="../assets/css/revisions_2026_10.css?v=20261002"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="auth-page auth-stacked"><div class="auth-shell auth-shell-login">
<header class="auth-welcome"><div class="auth-welcome-content"><div class="auth-logo"><img src="../assets/images/logo.png" alt="SupremeDent logo"></div><h1>Welcome to SupremeDent</h1><p>Manage appointments, dental records, treatment plans, and dental care in one secure place.</p></div></header>
<main class="auth-form-panel"><a href="../index.php" class="auth-back"><i class="fa-solid fa-arrow-left"></i> Back to Home</a><div class="auth-form-wrap">
<div class="auth-wordmark">SUPREMEDENT</div><p class="auth-kicker">Sign in to your account</p>
<?php if($message):?><div class="auth-message is-error" style="display:block" role="alert" id="loginMessage"<?php if($lockSeconds>0):?> data-lock-seconds="<?=(int)$lockSeconds?>"<?php endif;?>><span id="loginMessageText"><?=e($message)?></span><?php if($wrongPassword||$lockSeconds>0):?> <a href="forgot_password.php">Forgotten password?</a><?php endif;?></div><?php endif;?>
<?php if(isset($_GET['reset'])):?><div class="auth-message is-success" style="display:block" role="status">Password reset successfully. You can now log in.</div><?php endif;?>
<?php if(isset($_GET['verified'])||isset($_GET['registered'])):?><div class="auth-message is-success" style="display:block" role="status"><i class="fa-solid fa-circle-check"></i> Account verified. You can now log in.</div><?php endif;?>
<form method="post" autocomplete="off" id="loginForm">
<input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="credential-decoy" aria-hidden="true"><input type="text" tabindex="-1" autocomplete="username"><input type="password" tabindex="-1" autocomplete="new-password"></div>
<div class="auth-field"><label for="login_email">Email Address</label><input type="email" id="login_email" name="login_email" class="input-field" maxlength="150" placeholder="Enter your email" value="<?=e($emailValue)?>" autocomplete="off" autocapitalize="none" spellcheck="false" data-lpignore="true" data-1p-ignore="true" readonly required><div class="field-feedback" id="emailFeedback" aria-live="polite"></div></div>
<div class="auth-field"><label for="login_password">Password</label><div class="password-control"><input type="password" id="login_password" name="login_password" class="input-field" maxlength="128" placeholder="Enter your password" autocomplete="new-password" data-lpignore="true" data-1p-ignore="true" readonly required><button type="button" class="password-toggle" data-toggle-password="login_password" aria-label="Show password" aria-pressed="false"><i class="fa-regular fa-eye-slash"></i></button></div></div>
<div class="options-row login-options"><span></span><a class="forgot-link" href="forgot_password.php">Forgot password?</a></div>
<button type="submit" class="btn btn-primary">Log In</button>
</form>
<div class="auth-footer">Don't have a patient account? <a href="signup.php">Create an account</a></div>
</div></main></div></div>
<script>
const emailInput=document.getElementById('login_email'),passwordInput=document.getElementById('login_password'),emailFeedback=document.getElementById('emailFeedback');
[emailInput,passwordInput].forEach(input=>{const unlock=()=>input.removeAttribute('readonly');input.addEventListener('focus',unlock,{once:true});input.addEventListener('pointerdown',unlock,{once:true});});
function validSupremeDentEmail(value){value=value.trim();if(value.length<5||value.length>150||value.split('@').length!==2)return false;const [local,domainRaw]=value.split('@'),domain=domainRaw.toLowerCase();if(!/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(local)||local.includes('..'))return false;if(!/^(?=.{3,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/i.test(domain)||domain.includes('..'))return false;if(/\.(com|net|org|edu|gov|ph)\.\1$/i.test(domain))return false;const providers={'gmail.':['gmail.com'],'googlemail.':['googlemail.com'],'outlook.':['outlook.com'],'hotmail.':['hotmail.com'],'icloud.':['icloud.com']};for(const [prefix,allowed] of Object.entries(providers)){if(domain.startsWith(prefix)&&!allowed.includes(domain))return false}return true}
function updateEmailFeedback(){const v=emailInput.value.trim();if(!v){emailFeedback.textContent='';emailFeedback.className='field-feedback';emailInput.setCustomValidity('');return true}const ok=validSupremeDentEmail(v);emailFeedback.textContent=ok?'':'Please enter a valid email address.';emailFeedback.className='field-feedback '+(ok?'':'bad');emailInput.setCustomValidity(ok?'':'Enter a valid email address.');return ok}
emailInput.addEventListener('input',updateEmailFeedback);emailInput.addEventListener('blur',updateEmailFeedback);updateEmailFeedback();
// Open eye = password is visible, slashed eye = password is hidden.
document.querySelectorAll('[data-toggle-password]').forEach(button=>button.addEventListener('click',function(){const input=document.getElementById(this.dataset.togglePassword),icon=this.querySelector('i');if(!input)return;input.removeAttribute('readonly');const show=input.type==='password';input.type=show?'text':'password';icon.classList.toggle('fa-eye',show);icon.classList.toggle('fa-eye-slash',!show);this.setAttribute('aria-label',show?'Hide password':'Show password');this.setAttribute('aria-pressed',String(show))}));
// Lockout countdown: the Log In button stays disabled until the wait time is over.
(()=>{const box=document.getElementById('loginMessage');if(!box||!box.dataset.lockSeconds)return;const text=document.getElementById('loginMessageText'),btn=document.querySelector('#loginForm button[type=submit]');const end=Date.now()+Number(box.dataset.lockSeconds)*1000;function tick(){const left=Math.max(0,Math.ceil((end-Date.now())/1000));if(!left){text.textContent='You can try signing in again now.';box.classList.remove('is-error');box.classList.add('is-success');btn.disabled=false;btn.textContent='Log In';clearInterval(t);return}const m=Math.floor(left/60),s=String(left%60).padStart(2,'0');text.textContent='Too many failed sign-in attempts. Please wait '+m+':'+s+' before trying again.';btn.disabled=true;btn.textContent='Try again in '+m+':'+s}const t=setInterval(tick,1000);tick()})();
document.getElementById('loginForm').addEventListener('submit',e=>{emailInput.removeAttribute('readonly');passwordInput.removeAttribute('readonly');if(!updateEmailFeedback()||!passwordInput.value){e.preventDefault();if(!updateEmailFeedback())emailInput.focus();else passwordInput.focus();}});
</script>
</body></html>
