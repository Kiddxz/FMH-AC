<?php
require_once __DIR__ . '/../config/security.php';
// Signs out of one portal only (patient, assistant, dentist or super admin); the other portals that are
// signed in on this browser stay signed in. If the portal cannot be told, every portal is signed out.
if (request_portal() !== '') {
    start_secure_session();
    destroy_secure_session();
} else {
    apply_security_headers();
    destroy_all_portal_sessions();
}
// The general (sign-in) session never keeps a pending password-reset authorization after a sign-out.
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
$general = $_COOKIE[portal_session_name('')] ?? '';
if (is_string($general) && preg_match('/^[A-Za-z0-9,-]{22,256}$/', $general)) {
    configure_session_cookie();
    session_name(portal_session_name(''));
    session_id($general);
    session_start();
    unset($_SESSION['reset_user_id'], $_SESSION['reset_verified_at']);
    session_write_close();
}
header('Location: login.php');
exit;
