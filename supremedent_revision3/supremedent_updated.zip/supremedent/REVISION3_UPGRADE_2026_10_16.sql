-- SupremeDent revision 3 (2026-10-16) database upgrade.
-- Optional: the website applies these automatically on first page load (config/schema.php).
-- Run REVISION2_UPGRADE_2026_10_09.sql first if your database is older than revision 2.
-- Back up the database before running this file manually in phpMyAdmin.
USE supremedent_db;

-- Created by the website on first load; included here so this file also works on its own.
CREATE TABLE IF NOT EXISTS restoration_orders (id INT AUTO_INCREMENT PRIMARY KEY, patient_id INT NOT NULL, dentist_id INT NOT NULL, treatment_plan_id INT NULL, restoration_type ENUM('removable','fixed') NOT NULL, order_no VARCHAR(50) NULL, date_sent DATE NULL, date_due DATE NULL, phone VARCHAR(50) NULL, sex VARCHAR(30) NULL, age VARCHAR(20) NULL, selected_teeth TEXT NULL, work_options LONGTEXT NULL, teeth_material_options LONGTEXT NULL, shade VARCHAR(100) NULL, mould VARCHAR(100) NULL, staining_options LONGTEXT NULL, metal_design VARCHAR(80) NULL, pontic_design VARCHAR(80) NULL, instructions TEXT NULL, status ENUM('Draft','Sent','In Progress','Ready','Completed','Cancelled') NOT NULL DEFAULT 'Draft', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX(patient_id), INDEX(dentist_id), INDEX(restoration_type), INDEX(status), INDEX(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE users ADD COLUMN IF NOT EXISTS patient_no INT NULL;
ALTER TABLE users ADD UNIQUE INDEX IF NOT EXISTS uniq_users_patient_no (patient_no);
ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS source VARCHAR(10) NOT NULL DEFAULT 'online';
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS walkin_status VARCHAR(20) NULL;
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS created_by INT NULL;
UPDATE appointments SET source='walkin', walkin_status=IF(status='completed','completed','waiting') WHERE source='online' AND reason LIKE 'Walk-in%';
ALTER TABLE dental_charts ADD COLUMN IF NOT EXISTS service VARCHAR(150) NULL AFTER chart_date;
ALTER TABLE dental_charts ADD COLUMN IF NOT EXISTS chart_time TIME NULL AFTER chart_date;
ALTER TABLE restoration_orders MODIFY COLUMN metal_design TEXT NULL;
ALTER TABLE restoration_orders MODIFY COLUMN pontic_design TEXT NULL;
ALTER TABLE restoration_orders ADD COLUMN IF NOT EXISTS created_by INT NULL;
ALTER TABLE restoration_orders ADD COLUMN IF NOT EXISTS created_role VARCHAR(20) NULL;
UPDATE clinic_settings SET setting_value='0' WHERE setting_key='booking_lead_hours';

-- Patient numbers 000001, 000002, ... in registration order (new patients are numbered automatically).
SET @n := (SELECT COALESCE(MAX(patient_no),0) FROM users);
UPDATE users SET patient_no = (@n := @n + 1) WHERE role='patient' AND patient_no IS NULL ORDER BY created_at, id;

INSERT INTO clinic_settings (setting_key,setting_value) VALUES ('schema_revision','3') ON DUPLICATE KEY UPDATE setting_value='3';
