<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'assistant', false);
require_once __DIR__ . '/../includes/appointment_helpers.php';

$uid = (int)$_SESSION['user_id'];
$msg = '';
$type = '';
$dentists = [];
$r = $conn->query("SELECT id,first_name,last_name FROM users WHERE role='dentist' AND status='active' ORDER BY last_name,first_name");
if ($r) $dentists = $r->fetch_all(MYSQLI_ASSOC);
$patients = [];
$r = $conn->query("SELECT id,first_name,last_name,email,patient_no FROM users WHERE role='patient' AND status='active' ORDER BY last_name,first_name");
if ($r) $patients = $r->fetch_all(MYSQLI_ASSOC);
$services = [];
$r = $conn->query("SELECT name FROM services WHERE is_active=1 ORDER BY id");
if ($r) while ($s = $r->fetch_assoc()) $services[] = $s['name'];
if (!$services) $services = ['Dental Checkup', 'Dental Cleaning', 'Dental Restoration', 'Tooth Extraction', 'Consultation'];
$dentistIds = array_map(static fn($d) => (int)$d['id'], $dentists);
$walkStates = ['waiting', 'in_chair', 'completed'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if (!csrf_valid($_POST['csrf_token'] ?? null)) {
        $msg = 'Your session expired. Refresh and try again.';
        $type = 'error';
    } elseif ($action === 'walkin') {
        // Walk-in: a registered patient who arrived without an online booking. The dentist can be assigned later.
        $pid = (int)($_POST['patient_id'] ?? 0);
        $dentistId = (int)($_POST['dentist_id'] ?? 0);
        $date = (string)($_POST['appointment_date'] ?? date('Y-m-d'));
        $time = substr((string)($_POST['appointment_time'] ?? date('H:i')), 0, 5);
        $service = trim((string)($_POST['appointment_type'] ?? ''));
        $reason = mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 255);
        $walk = in_array($_POST['walkin_status'] ?? '', ['waiting', 'in_chair'], true) ? $_POST['walkin_status'] : 'waiting';
        if ($dentistId === 0) $walk = 'waiting';
        $validPatient = in_array($pid, array_map(static fn($p) => (int)$p['id'], $patients), true);
        if (!$validPatient || !in_array($service, $services, true)) { $msg = 'Select a registered patient and a service.'; $type = 'error'; }
        elseif ($dentistId && !in_array($dentistId, $dentistIds, true)) { $msg = 'Select a valid dentist.'; $type = 'error'; }
        elseif (!clinic_open_day($date) || !preg_match('/^\d{2}:\d{2}$/', $time)) { $msg = 'Enter a valid arrival date and time. The clinic is closed on Sundays.'; $type = 'error'; }
        else {
            $busy = false;
            if ($dentistId) {
                $check = $conn->prepare("SELECT id FROM appointments WHERE dentist_id=? AND appointment_date=? AND appointment_time=? AND status IN ('pending','approved') LIMIT 1");
                $check->bind_param('iss', $dentistId, $date, $time);
                $check->execute();
                $busy = $check->get_result()->num_rows > 0;
                $check->close();
            }
            if ($busy) { $msg = 'That dentist already has an appointment at this time.'; $type = 'error'; }
            elseif ($dentistId && sd_staff_unavailable($conn, $dentistId, $date, $time)) { $msg = 'That dentist marked this schedule as unavailable.'; $type = 'error'; }
            else {
                $dentistParam = $dentistId ?: null;
                $st = $conn->prepare("INSERT INTO appointments(patient_id,dentist_id,appointment_date,appointment_time,appointment_type,reason,status,source,walkin_status,created_by) VALUES(?,?,?,?,?,?,'approved','walkin',?,?)");
                $st->bind_param('iisssssi', $pid, $dentistParam, $date, $time, $service, $reason, $walk, $uid);
                $st->execute();
                $newId = (int)$st->insert_id;
                $st->close();
                $when = date('M d, Y', strtotime($date)) . ' at ' . date('h:i A', strtotime($time));
                sd_notify_patient($conn, $pid, 'Walk-in Visit Recorded', 'Your clinic visit on ' . $when . ' (' . $service . ') has been recorded.', 'appointment', $newId);
                $pname = '';
                foreach ($patients as $p) if ((int)$p['id'] === $pid) $pname = $p['first_name'] . ' ' . $p['last_name'];
                sd_notify_staff($conn, $dentistId ? [] : ['dentist'], $dentistId ? [$dentistId] : [], 'Walk-in patient · ' . $pname, $pname . ' arrived for ' . $service . ' on ' . $when . ($dentistId ? '.' : ' and is waiting for a dentist.'), $newId, $pid, $uid);
                log_activity($conn, $uid, 'Recorded walk-in', 'Appointments', 'Appointment #' . $newId);
                header('Location: appointments.php?tab=walkin&done=walkin');
                exit;
            }
        }
    } elseif ($action === 'walkin_update') {
        $id = (int)($_POST['appointment_id'] ?? 0);
        $walk = in_array($_POST['walkin_status'] ?? '', $walkStates, true) ? $_POST['walkin_status'] : 'waiting';
        $dentistId = (int)($_POST['dentist_id'] ?? 0);
        $a = sd_load_appointment($conn, $id);
        if (!$a || ($a['source'] ?? '') !== 'walkin' || $a['status'] === 'cancelled') { $msg = 'Walk-in not found.'; $type = 'error'; }
        elseif ($dentistId && !in_array($dentistId, $dentistIds, true)) { $msg = 'Select a valid dentist.'; $type = 'error'; }
        elseif ($walk !== 'waiting' && !$dentistId) { $msg = 'Assign a dentist before moving the patient to the chair.'; $type = 'error'; }
        else {
            $status = $walk === 'completed' ? 'completed' : 'approved';
            $dentistParam = $dentistId ?: null;
            $st = $conn->prepare("UPDATE appointments SET walkin_status=?, status=?, dentist_id=? WHERE id=? AND source='walkin'");
            $st->bind_param('ssii', $walk, $status, $dentistParam, $id);
            $st->execute();
            $st->close();
            if ($dentistId && (int)$a['dentist_id'] !== $dentistId) {
                $pname = trim($a['first_name'] . ' ' . $a['last_name']);
                sd_notify_staff($conn, [], [$dentistId], 'Walk-in assigned · ' . $pname, $pname . ' (' . $a['appointment_type'] . ') was assigned to you.', $id, (int)$a['patient_id'], $uid);
            }
            log_activity($conn, $uid, 'Updated walk-in', 'Appointments', 'Appointment #' . $id . ' · ' . $walk);
            header('Location: appointments.php?tab=walkin&done=walkin_updated');
            exit;
        }
    } elseif ($action === 'cancel') {
        [$ok, $text] = sd_cancel_appointment($conn, (int)($_POST['appointment_id'] ?? 0), $uid, 'assistant', (string)($_POST['cancel_reason'] ?? ''));
        $msg = $ok ? $text . ' The patient was notified.' : $text;
        $type = $ok ? 'success' : 'error';
    } else {
        $msg = 'Invalid action.';
        $type = 'error';
    }
}
$done = $_GET['done'] ?? '';
if (!$msg && $done === 'walkin') { $msg = 'Walk-in patient recorded.'; $type = 'success'; }
if (!$msg && $done === 'walkin_updated') { $msg = 'Walk-in updated.'; $type = 'success'; }

$rows = [];
$r = $conn->query("SELECT a.*,u.first_name,u.last_name,u.email,u.patient_no,d.first_name dentist_first,d.last_name dentist_last FROM appointments a JOIN users u ON u.id=a.patient_id LEFT JOIN users d ON d.id=a.dentist_id AND d.role='dentist' ORDER BY a.appointment_date DESC,a.appointment_time DESC,a.id DESC");
if ($r) $rows = $r->fetch_all(MYSQLI_ASSOC);
$viewData = [];
foreach ($rows as $x) $viewData[(int)$x['id']] = sd_appointment_view_data($x);
$calendarRole = 'assistant';
$calendarEvents = array_values(array_filter($rows, static fn($a) => in_array($a['status'], ['pending', 'approved', 'completed'], true)));
$calendarBlocks = [];
$blockResult = $conn->query("SELECT p.id,p.unavailable_date,p.start_time,p.end_time,p.all_day,p.reason,CONCAT(u.first_name,' ',u.last_name) staff_name FROM provider_unavailability p JOIN users u ON u.id=p.user_id AND u.role='dentist' WHERE p.unavailable_date>=DATE_SUB(CURDATE(),INTERVAL 60 DAY) ORDER BY p.unavailable_date,p.start_time");
if ($blockResult) while ($b = $blockResult->fetch_assoc()) $calendarBlocks[] = $b;

$view = ($_GET['view'] ?? '') === 'calendar' ? 'calendar' : 'requests';
require '../includes/ui.php';
ui_header($view === 'calendar' ? 'Appointment View' : 'Appointment Requests', 'assistant');
ui_sidebar('assistant', 'appointments.php');
if ($view === 'calendar'): ?>
<div class="page-head compact-head"><div><div class="eyebrow">APPOINTMENT DESK</div><h1>Appointment View</h1><div class="muted">Every patient appointment on one calendar. Click a date to see who is scheduled.</div></div><a class="btn btn-primary" href="appointments.php"><i class="fa-solid fa-list-check"></i> Appointment Requests</a></div>
<?php if ($msg) flash($type, $msg); ?>
<?php require '../includes/appointment_calendar.php'; ?>
<?php else:
    $reqRole = 'assistant';
    require '../includes/appointment_requests.php';
endif;
$viewModalWalkinForm = true;
$viewModalDentists = $dentists;
require '../includes/appointment_view_modal.php'; ?>
<script>(()=>{const data=<?= json_encode((object)$viewData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;document.querySelectorAll('[data-view-appt]').forEach(b=>b.addEventListener('click',()=>openAppointmentView(data[b.dataset.viewAppt])));})();</script>
<?php ui_footer(); ?>
