<?php
// Revision 3: patient details moved to patient_record.php (Dental Record / Treatment Plan Record / Appointment Record).
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'assistant', false);
header('Location: patient_record.php?id=' . (int)($_GET['id'] ?? 0), true, 302);
exit;
