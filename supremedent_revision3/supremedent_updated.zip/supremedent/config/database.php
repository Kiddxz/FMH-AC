<?php
date_default_timezone_set('Asia/Manila');
$host = "localhost";
$username = "root";
$password = "";
$database = "supremedent_db";
// When MySQL is not running (XAMPP > MySQL > Start), show a clear message instead of a PHP fatal error.
function sd_database_unavailable(string $detail): void
{
    error_log('[SupremeDent database] ' . $detail);
    if (!headers_sent()) { http_response_code(503); header('Retry-After: 10'); header('Cache-Control: no-store'); }
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $wantsJson = str_contains($script, '/api/') || str_contains((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json');
    if ($wantsJson) {
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'success' => false, 'message' => 'The database is not running. Start MySQL in XAMPP.']);
        exit;
    }
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Database not running | SupremeDent</title>'
        . '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f4f9f8;font-family:Arial,sans-serif;color:#17303a}.box{max-width:560px;margin:16px;padding:30px;border-radius:18px;background:#fff;box-shadow:0 12px 35px rgba(0,0,0,.08)}h1{margin:0 0 10px;font-size:22px}p,li{line-height:1.6;color:#4f6569}code{background:#eef3f2;padding:2px 6px;border-radius:5px}a{display:inline-block;margin-top:12px;padding:10px 18px;border-radius:10px;background:#135e63;color:#fff;text-decoration:none}</style></head>'
        . '<body><div class="box"><h1>The database is not running</h1><p>SupremeDent could not connect to MySQL.</p><ol><li>Open the <b>XAMPP Control Panel</b>.</li><li>Click <b>Start</b> beside <b>MySQL</b> and wait until it turns green.</li><li>Reload this page.</li></ol>'
        . '<p>If MySQL stops right after starting, click <b>Logs</b> beside MySQL in XAMPP to see why.</p><a href="javascript:location.reload()">Reload</a></div></body></html>';
    exit;
}
try {
    $conn = new mysqli($host, $username, $password, $database);
} catch (mysqli_sql_exception $e) {
    sd_database_unavailable($e->getMessage());
}
if ($conn->connect_error) sd_database_unavailable($conn->connect_error);
$conn->set_charset("utf8mb4");
// Match OTP timestamps to the PHP Asia/Manila clock.
$conn->query("SET time_zone = '+08:00'");
// A page should never wait long for a table lock (e.g. while phpMyAdmin or an upgrade holds one).
try { $conn->query('SET SESSION lock_wait_timeout = 15'); } catch (Throwable $e) {}
require_once __DIR__ . '/schema.php';
ensure_schema($conn);
?>
