<?php
/**
 * SupremeDent local SMS settings (this file is excluded by .gitignore).
 *
 * Patient contact-number OTPs are sent through IPROG SMS (https://sms.iprogtech.com).
 * The token below is the clinic's IPROG "Main API token" (Dashboard > API access).
 * Each SMS uses IPROG credits, so keep credits loaded on the IPROG account.
 */
return [
    'provider' => 'iprog',
    'iprog_api_token' => 'a88d4898dd3a320e43a80e7a8253ab14c5040c88',
    // true = write OTPs to storage/otp.log instead of sending a real SMS (local testing only).
    'log_only' => false,

    // Optional Infobip fallback (set 'provider' => 'infobip' to use it).
    'api_key' => 'ed4125ab759bb77b2d36abc3e427a3b2-20ee21f4-7bc7-4eaa-b092-03afa2d0d329',
    'base_url' => 'm9kxgj.api.infobip.com',
    'sender' => 'ServiceSMS',
];
