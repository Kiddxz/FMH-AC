<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'dentist', false);
require_once __DIR__ . '/../includes/appointment_helpers.php';


$uid = (int) $_SESSION['user_id'];
$msg = '';
$type = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid($_POST['csrf_token'] ?? null)) {
        $msg = 'Your session expired. Refresh and try again.';
        $type = 'error';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'complete') {
            $id = (int) ($_POST['appointment_id'] ?? 0);
            // Unassigned bookings are taken by the dentist who completes them.
            $st = $conn->prepare("UPDATE appointments SET status='completed', dentist_id=COALESCE(dentist_id, ?) WHERE id=? AND (dentist_id=? OR dentist_id IS NULL) AND status='approved'");
            $st->bind_param('iii', $uid, $id, $uid);
            $st->execute();
            $changed = $st->affected_rows;
            $st->close();
            $msg = $changed ? 'Appointment marked completed.' : 'Only your approved (or unassigned) appointments can be completed.';
            $type = $changed ? 'success' : 'error';
        } elseif ($action === 'cancel') {
            [$ok, $text] = sd_cancel_appointment($conn, (int) ($_POST['appointment_id'] ?? 0), $uid, 'dentist', (string) ($_POST['cancel_reason'] ?? ''));
            $msg = $ok ? $text . ' The patient was notified.' : $text;
            $type = $ok ? 'success' : 'error';
        } elseif ($action === 'block') {
            $date = $_POST['unavailable_date'] ?? '';
            $allDay = isset($_POST['all_day']) ? 1 : 0;
            $start = $allDay ? null : ($_POST['start_time'] ?? null);
            $end = $allDay ? null : ($_POST['end_time'] ?? null);
            $reason = trim($_POST['reason'] ?? 'Unavailable');
            if (!clinic_open_day($date) || (!$allDay && (!$start || !$end || $start >= $end))) {
                $msg = 'Choose a valid Monday–Saturday date and time. The clinic is closed on Sundays.';
                $type = 'error';
            } else {
                $st = $conn->prepare("INSERT INTO provider_unavailability(user_id,unavailable_date,start_time,end_time,all_day,reason,created_by) VALUES(?,?,?,?,?,?,?)");
                $st->bind_param('isssisi', $uid, $date, $start, $end, $allDay, $reason, $uid);
                $st->execute();
                $st->close();
                $msg = 'Unavailable schedule added to your calendar.';
            }
        } elseif ($action === 'unblock') {
            $id = (int) ($_POST['block_id'] ?? 0);
            $st = $conn->prepare('DELETE FROM provider_unavailability WHERE id=? AND user_id=?');
            $st->bind_param('ii', $id, $uid);
            $st->execute();
            $st->close();
            $msg = 'Unavailable mark removed.';
        }
    }
}
$events = [];
// The calendar shows every booking so the dentist can see who is scheduled at each date and time.
$st = $conn->prepare("SELECT a.id,a.patient_id,a.dentist_id,a.appointment_date,a.appointment_time,a.appointment_type,a.reason,a.marked_teeth,a.status,a.cancel_reason,a.source,a.walkin_status,u.first_name,u.last_name,u.email,u.patient_no,d.first_name dentist_first,d.last_name dentist_last FROM appointments a JOIN users u ON u.id=a.patient_id LEFT JOIN users d ON d.id=a.dentist_id ORDER BY a.appointment_date,a.appointment_time");
$st->execute();
$r = $st->get_result();
$allAppointments = [];
while ($x = $r->fetch_assoc()) {
    $allAppointments[] = $x;
    if (in_array($x['status'], ['pending', 'approved', 'completed'], true)) $events[] = $x;
}
$st->close();
$viewData = [];
foreach ($allAppointments as $x) $viewData[(int) $x['id']] = sd_appointment_view_data($x);
$blocks = [];
$st = $conn->prepare("SELECT id,unavailable_date,start_time,end_time,all_day,reason FROM provider_unavailability WHERE user_id=? AND unavailable_date>=DATE_SUB(CURDATE(),INTERVAL 60 DAY) ORDER BY unavailable_date,start_time");
$st->bind_param('i', $uid);
$st->execute();
$r = $st->get_result();
while ($x = $r->fetch_assoc())
    $blocks[] = $x;
$st->close();
// Revision 3: the calendar is the main view; "Appointment Requests" opens the request list (same as the assistant's).
$view = ($_GET['view'] ?? '') === 'requests' ? 'requests' : 'calendar';
require '../includes/ui.php';
ui_header($view === 'requests' ? 'Appointment Requests' : 'Appointments', 'dentist');
ui_sidebar('dentist', 'appointments.php');
if ($view === 'requests'):
    $reqRole = 'dentist';
    $rows = $allAppointments;
    require '../includes/appointment_requests.php';
    require '../includes/appointment_view_modal.php'; ?>
<script>(()=>{const data=<?= json_encode((object) $viewData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;document.querySelectorAll('[data-view-appt]').forEach(b=>b.addEventListener('click',()=>openAppointmentView(data[b.dataset.viewAppt])));})();</script>
<?php ui_footer(); exit; endif; ?>
<div class="page-head compact-head">
    <div>
        <div class="eyebrow">APPOINTMENT DESK</div>
        <h1>Appointment View</h1>
        <div class="muted">Every patient appointment on one calendar. Click a date to see who is scheduled.</div>
    </div>
    <a class="btn btn-primary" href="appointments.php?view=requests"><i class="fa-solid fa-list-check"></i> Appointment Requests</a>
</div><?php if ($msg)
    flash($type, $msg); ?>
<?php $calendarRole = 'dentist';
$calendarEvents = $events;
$calendarBlocks = $blocks;
require '../includes/appointment_calendar.php'; ?>
<?php require '../includes/appointment_view_modal.php'; ?>
<details class="card tool-panel sd-unavailability-card"><summary><span><b>Mark Unavailable</b><small>Block a full day or a specific time period on your calendar.</small></span><i class="fa-solid fa-chevron-down"></i></summary>
<form method="post" class="form-grid compact"><input type="hidden" name="csrf_token"
                value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="block">
            <div class="field"><label>Date</label><input type="date" name="unavailable_date" min="<?= date('Y-m-d') ?>"
                    required></div>
            <div class="field checkbox-field"><label><input type="checkbox" name="all_day" value="1" checked
                        id="allDayToggle"> All day</label></div>
            <div class="field time-block"><label>Start</label><input type="time" name="start_time" value="09:00"></div>
            <div class="field time-block"><label>End</label><input type="time" name="end_time" value="17:00"></div>
            <div class="field full"><label>Reason</label><input name="reason" maxlength="255"
                    placeholder="e.g. Leave, training, personal appointment"></div>
            <div class="actions full"><button class="btn btn-primary">Save Unavailable Time</button></div>
        </form>
        <div class="unavailability-list"><?php foreach (array_slice($blocks, 0, 8) as $b): ?>
                <div class="unavailability-row">
                    <span><b><?= e(date('M d, Y', strtotime($b['unavailable_date']))) ?></b><small><?= $b['all_day'] ? 'All day' : e(date('h:i A', strtotime($b['start_time'])) . ' – ' . date('h:i A', strtotime($b['end_time']))) ?><?= $b['reason'] ? ' • ' . e($b['reason']) : '' ?></small></span>
                    <form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input
                            type="hidden" name="action" value="unblock"><input type="hidden" name="block_id"
                            value="<?= $b['id'] ?>"><button class="btn btn-danger">Remove</button></form>
                </div><?php endforeach; ?>
        </div>
</details>
<script>document.getElementById('allDayToggle').addEventListener('change', function () {document.querySelectorAll('.time-block').forEach(el => el.style.display = this.checked ? 'none' : '');}); document.getElementById('allDayToggle').dispatchEvent(new Event('change'));</script>
<?php ui_footer(); ?>