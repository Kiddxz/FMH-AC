<?php
// Revision 3: dental charts can no longer be deleted (the Delete button was removed). Clinical records are kept.
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'dentist', false);
header('Location: dental_charts.php');
exit;
