<?php
// Revision 3: Patient History was removed from the dentist portal. Each patient's dental records, treatment plans
// and appointments are under Patients > View.
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'dentist', false);
$pid = (int)($_GET['patient_id'] ?? 0);
header('Location: ' . ($pid ? 'patient_record.php?id=' . $pid : 'patients.php'), true, 302);
exit;
