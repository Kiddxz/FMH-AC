<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'dentist', false);

/*
 * Clinic Reports (revision 3): this week vs last week, a weekly bar chart and a weekly summary for the chosen
 * record type and date range, plus the matching records. Weeks run Sunday to Saturday (the clinic week).
 */
$types = [
    'appointments' => ['Appointments', 'appointments', "SELECT a.appointment_date d, CONCAT(u.first_name,' ',u.last_name) patient, a.appointment_type item, a.status FROM appointments a JOIN users u ON u.id=a.patient_id WHERE a.status<>'cancelled' AND a.appointment_date BETWEEN ? AND ? ORDER BY a.appointment_date DESC, a.appointment_time DESC"],
    'treatments' => ['Treatment Plans', 'treatment plans', "SELECT DATE(tp.created_at) d, CONCAT(u.first_name,' ',u.last_name) patient, tp.procedure_name item, tp.status FROM treatment_plans tp JOIN users u ON u.id=tp.patient_id WHERE DATE(tp.created_at) BETWEEN ? AND ? ORDER BY tp.created_at DESC"],
    'charts' => ['Dental Charts', 'dental charts', "SELECT COALESCE(c.chart_date,DATE(c.created_at)) d, CONCAT(u.first_name,' ',u.last_name) patient, COALESCE(NULLIF(c.service,''),'Dental examination') item, COALESCE(c.created_role,'dentist') status FROM dental_charts c JOIN users u ON u.id=c.patient_id WHERE COALESCE(c.chart_date,DATE(c.created_at)) BETWEEN ? AND ? ORDER BY d DESC, c.id DESC"],
    'history' => ['Dental Records', 'dental records', "SELECT d.record_date d, CONCAT(u.first_name,' ',u.last_name) patient, d.procedure_name item, COALESCE(d.diagnosis,'') status FROM dental_records d JOIN users u ON u.id=d.patient_id WHERE d.record_date BETWEEN ? AND ? ORDER BY d.record_date DESC"],
];
if ((clinic_settings($conn)['laboratory_enabled'] ?? '0') === '1') {
    $types['laboratory'] = ['Laboratory', 'laboratory cases', "SELECT lc.request_date d, CONCAT(u.first_name,' ',u.last_name) patient, CONCAT(lc.case_type,' / ',lc.laboratory_name) item, lc.status FROM laboratory_cases lc JOIN users u ON u.id=lc.patient_id WHERE lc.request_date BETWEEN ? AND ? ORDER BY lc.request_date DESC"];
}
$type = isset($types[$_GET['type'] ?? '']) ? $_GET['type'] : 'appointments';
[$typeLabel, $noun, $sql] = $types[$type];

$weekStart = static fn(DateTimeImmutable $d) => $d->modify('-' . (int)$d->format('w') . ' days');
$today = new DateTimeImmutable('today');
$validDate = static function ($v): ?DateTimeImmutable { $d = DateTimeImmutable::createFromFormat('!Y-m-d', (string)$v); return $d && $d->format('Y-m-d') === $v ? $d : null; };
$to = $validDate($_GET['to'] ?? '') ?? $weekStart($today)->modify('+6 days');
$from = $validDate($_GET['from'] ?? '') ?? $weekStart($to)->modify('-7 weeks');
if ($from > $to) [$from, $to] = [$to, $from];
$firstWeek = $weekStart($from);
$lastWeek = $weekStart($to);
if ((int)$firstWeek->diff($lastWeek)->days > 7 * 52) $firstWeek = $lastWeek->modify('-52 weeks'); // at most a year of weeks

$st = $conn->prepare($sql);
$f = $firstWeek->format('Y-m-d');
$t = $lastWeek->modify('+6 days')->format('Y-m-d');
$st->bind_param('ss', $f, $t);
$st->execute();
$all = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$st->close();

$weeks = [];
for ($w = $firstWeek; $w <= $lastWeek; $w = $w->modify('+1 week')) $weeks[$w->format('Y-m-d')] = ['start' => $w, 'count' => 0];
foreach ($all as $row) {
    $k = $weekStart(new DateTimeImmutable($row['d']))->format('Y-m-d');
    if (isset($weeks[$k])) $weeks[$k]['count']++;
}
$weeks = array_values($weeks);
foreach ($weeks as $i => &$w) {
    $prev = $i > 0 ? $weeks[$i - 1]['count'] : null;
    $w['diff'] = $prev === null ? null : $w['count'] - $prev;
    $w['pct'] = $prev ? round(($w['count'] - $prev) / $prev * 100, 1) : null;
    $w['label'] = $w['start']->format('M j');
    $end = $w['start']->modify('+6 days');
    $w['range'] = $w['start']->format('M j') . ' – ' . ($end->format('M') === $w['start']->format('M') ? $end->format('j') : $end->format('M j'));
}
unset($w);
$cur = end($weeks);
$prevWeek = count($weeks) > 1 ? $weeks[count($weeks) - 2] : null;
$records = array_values(array_filter($all, static fn($r) => $r['d'] >= $from->format('Y-m-d') && $r['d'] <= $to->format('Y-m-d')));
$max = max(1, ...array_map(static fn($w) => $w['count'], $weeks));
$niceMax = (int)(ceil($max / 6) * 6);
$fmtPct = static fn(?float $p) => $p === null ? '—' : (($p > 0 ? '' : '') . number_format(abs($p), $p == (int)$p ? 0 : 1) . '%');

require '../includes/ui.php';
ui_header('Reports', 'dentist');
ui_sidebar('dentist', 'reports.php'); ?>
<div class="page-head compact-head r3-report-head"><div><div class="eyebrow">REPORTS</div><h1>Clinic Reports</h1><div class="muted">Generate reports from real system records.</div></div><button type="button" class="r3-back" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button></div>
<form class="r3-report-filters r3-no-print" method="get">
    <select name="type" aria-label="Report type"><?php foreach ($types as $k => [$label]): ?><option value="<?= e($k) ?>" <?= $k === $type ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?></select>
    <input type="date" name="from" value="<?= e($from->format('Y-m-d')) ?>" aria-label="From date"><span aria-hidden="true">→</span><input type="date" name="to" value="<?= e($to->format('Y-m-d')) ?>" aria-label="To date">
    <button class="btn btn-primary">Generate</button>
</form>
<section class="r3-report-stats">
    <div class="r3-card"><span>This week</span><b><?= (int)$cur['count'] ?></b><small><?= e($noun) ?> · <?= e($cur['range']) ?></small></div>
    <div class="r3-card"><span>Last week</span><b><?= $prevWeek ? (int)$prevWeek['count'] : '—' ?></b><small><?= $prevWeek ? e($noun) . ' · ' . e($prevWeek['range']) : 'No earlier week in this range' ?></small></div>
    <?php $d = $cur['diff']; $cls = $d === null || $d === 0 ? 'flat' : ($d > 0 ? 'up' : 'down'); ?>
    <div class="r3-card r3-change <?= $cls ?>"><span>Change</span><b><?php if ($cls === 'up'): ?><i class="fa-solid fa-caret-up" aria-hidden="true"></i><?php elseif ($cls === 'down'): ?><i class="fa-solid fa-caret-down" aria-hidden="true"></i><?php endif; ?><?= $cur['pct'] === null ? ($d === null ? '—' : ($d === 0 ? '0%' : 'New')) : e($fmtPct($cur['pct'])) ?></b><small><?= $d === null ? 'Needs two weeks to compare' : ($d === 0 ? 'Same as last week' : abs($d) . ' ' . ($d > 0 ? 'more' : 'fewer') . ' ' . e($noun) . ' than last week') ?></small></div>
</section>
<section class="r3-card r3-chart-card">
    <div class="r3-card-head"><div><h2>Weekly <?= e(strtolower($typeLabel)) ?></h2><p class="muted">Last <?= count($weeks) ?> week<?= count($weeks) === 1 ? '' : 's' ?> · <span class="r3-up-txt">▲</span> increase, <span class="r3-down-txt">▼</span> decrease vs previous week</p></div></div>
    <div class="r3-bars" role="img" aria-label="<?= e('Weekly ' . strtolower($typeLabel) . ': ' . implode(', ', array_map(static fn($w) => $w['label'] . ' ' . $w['count'], $weeks))) ?>">
        <div class="r3-bars-axis" aria-hidden="true"><?php for ($i = 4; $i >= 0; $i--): ?><span style="bottom: <?= $i * 25 ?>%"><?= (int)round($niceMax * $i / 4) ?></span><?php endfor; ?></div>
        <div class="r3-bars-plot">
            <?php for ($i = 1; $i <= 4; $i++): ?><i class="r3-grid-line" style="bottom: <?= $i * 25 ?>%"></i><?php endfor; ?>
            <?php foreach ($weeks as $i => $w): $last = $i === count($weeks) - 1; ?>
                <div class="r3-bar-col" tabindex="0" data-tip="<?= e($w['range'] . ': ' . $w['count'] . ' ' . $noun . ($w['diff'] !== null ? ' (' . ($w['diff'] >= 0 ? '+' : '') . $w['diff'] . ' vs previous week)' : '')) ?>">
                    <div class="r3-bar-track"><b class="r3-bar-val"><?= (int)$w['count'] ?></b><i class="r3-bar<?= $last ? ' latest' : '' ?>" style="height: <?= round($w['count'] / $niceMax * 100, 2) ?>%"></i></div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="r3-bars-labels" aria-hidden="true">
            <?php foreach ($weeks as $w): ?><div><span><?= e($w['label']) ?></span><?php if ($w['pct'] !== null && $w['diff'] !== 0): ?><small class="<?= $w['diff'] > 0 ? 'up' : 'down' ?>"><?= $w['diff'] > 0 ? '▲' : '▼' ?> <?= e(number_format(abs($w['pct']), 0)) ?>%</small><?php elseif ($w['diff'] === 0): ?><small class="flat">0%</small><?php endif; ?></div><?php endforeach; ?>
        </div>
        <div class="r3-bar-tip" hidden></div>
    </div>
</section>
<section class="r3-card">
    <div class="r3-card-head"><h2>Weekly summary</h2></div>
    <table class="r3-table"><thead><tr><th>Week</th><th><?= e($typeLabel) ?></th><th>Change</th></tr></thead><tbody>
    <?php foreach (array_reverse($weeks) as $w): ?>
        <tr><td><b><?= e($w['range']) ?></b></td><td><?= (int)$w['count'] ?></td><td><?php if ($w['diff'] === null): ?><span class="muted">—</span><?php else: $c = $w['diff'] > 0 ? 'up' : ($w['diff'] < 0 ? 'down' : 'flat'); ?><span class="r3-change-pill <?= $c ?>"><?= $c === 'up' ? '▲' : ($c === 'down' ? '▼' : '') ?> <?= $w['pct'] === null ? ($w['diff'] === 0 ? '0%' : 'New') : e(number_format(abs($w['pct']), 1)) . '%' ?> (<?= $w['diff'] > 0 ? '+' : '' ?><?= (int)$w['diff'] ?>)</span><?php endif; ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
</section>
<section class="r3-card">
    <div class="r3-card-head"><div><h2><?= e($typeLabel) ?> records</h2><p class="muted"><?= e($from->format('M d, Y')) ?> – <?= e($to->format('M d, Y')) ?></p></div><span class="r3-count"><?= count($records) ?> record<?= count($records) === 1 ? '' : 's' ?></span></div>
    <div class="r3-table-scroll" style="--r3-rows-height: 420px">
    <table class="r3-table"><thead><tr><th>Date</th><th>Patient</th><th>Item</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($records as $r): ?><tr><td><?= e(date('M d, Y', strtotime($r['d']))) ?></td><td><?= e($r['patient']) ?></td><td><?= e($r['item']) ?></td><td><?= e($r['status'] === 'rejected' ? 'Declined' : ucfirst((string)$r['status'])) ?></td></tr><?php endforeach; ?>
    <?php if (!$records): ?><tr><td colspan="4" class="empty">No records found for the selected filters.</td></tr><?php endif; ?>
    </tbody></table>
    </div>
</section>
<script>
(() => {
    // Hover / focus tooltip for each week's bar.
    const chart = document.querySelector('.r3-bars'), tip = chart?.querySelector('.r3-bar-tip');
    if (!chart || !tip) return;
    const show = col => { const r = col.getBoundingClientRect(), c = chart.getBoundingClientRect(); tip.textContent = col.dataset.tip; tip.hidden = false; tip.style.left = Math.min(c.width - tip.offsetWidth - 4, Math.max(4, r.left - c.left + r.width / 2 - tip.offsetWidth / 2)) + 'px'; tip.style.top = '-6px'; col.classList.add('hover'); };
    const hide = col => { tip.hidden = true; col.classList.remove('hover'); };
    chart.querySelectorAll('.r3-bar-col').forEach(col => { col.addEventListener('mouseenter', () => show(col)); col.addEventListener('focus', () => show(col)); col.addEventListener('mouseleave', () => hide(col)); col.addEventListener('blur', () => hide(col)); });
})();
</script>
<?php ui_footer(); ?>
