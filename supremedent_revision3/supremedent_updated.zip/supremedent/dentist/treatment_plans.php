<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'dentist', false);
$plansRole = 'dentist';
require __DIR__ . '/../includes/treatment_plans_body.php';
