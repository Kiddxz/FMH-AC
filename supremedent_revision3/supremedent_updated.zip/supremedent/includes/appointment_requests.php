<?php
/**
 * Appointment Requests list (revision 3), shared by the assistant and dentist portals.
 * Tabs: Online Bookings and Walk-in. Newest date first; about six rows are visible and the rest scroll.
 * Inputs: $reqRole ('assistant'|'dentist'), $rows (appointments joined with patient/dentist names),
 * $patients, $dentists, $services (assistant walk-in form), $uid.
 */
$reqRole = ($reqRole ?? '') === 'dentist' ? 'dentist' : 'assistant';
$reqTab = ($_GET['tab'] ?? '') === 'walkin' ? 'walkin' : 'online';
$online = array_values(array_filter($rows, static fn($a) => ($a['source'] ?? 'online') !== 'walkin'));
$walkins = array_values(array_filter($rows, static fn($a) => ($a['source'] ?? 'online') === 'walkin'));
$latestFirst = static fn($a, $b) => [$b['appointment_date'], $b['appointment_time'], (int)$b['id']] <=> [$a['appointment_date'], $a['appointment_time'], (int)$a['id']];
usort($online, $latestFirst);
usort($walkins, $latestFirst);
$list = $reqTab === 'walkin' ? $walkins : $online;
$walkLabels = ['waiting' => 'Waiting', 'in_chair' => 'In chair', 'completed' => 'Completed'];
$base = 'appointments.php' . ($reqRole === 'dentist' ? '?view=requests&' : '?');
$dentistCell = static function (array $a) use ($reqRole, $uid): string {
    if ($reqRole === 'dentist' && (int)$a['dentist_id'] === $uid) return '<b class="r3-you">You</b>';
    return $a['dentist_first'] ? e($a['dentist_first'] . ' ' . $a['dentist_last']) : '<span class="muted">Not assigned</span>';
};
?>
<div class="page-head compact-head"><div><div class="eyebrow">APPOINTMENT DESK</div><h1>Appointment Requests</h1><div class="muted">Online bookings are confirmed automatically. Review them here<?= $reqRole === 'assistant' ? ' and record registered walk-in patients' : ' together with the walk-in patients recorded by the assistant' ?>.</div></div><a class="btn btn-primary" href="appointments.php<?= $reqRole === 'assistant' ? '?view=calendar' : '' ?>"><i class="fa-solid fa-calendar-days"></i> Appointment View</a></div>
<?php if (!empty($msg)) flash($type, $msg); ?>
<nav class="r3-tabs r3-req-tabs" aria-label="Appointment type">
    <a class="<?= $reqTab === 'online' ? 'active' : '' ?>" href="<?= e(rtrim($base, '?&')) ?>"><i class="fa-regular fa-calendar"></i> Online Bookings <span class="r3-tab-count"><?= count($online) ?></span></a>
    <a class="<?= $reqTab === 'walkin' ? 'active' : '' ?>" href="<?= e($base . 'tab=walkin') ?>"><i class="fa-solid fa-person-walking"></i> Walk-in <span class="r3-tab-count"><?= count($walkins) ?></span></a>
</nav>
<section class="r3-card requests-card" data-live-region="requests">
<?php if ($reqTab === 'online'): ?>
    <div class="r3-card-head"><div><h2>Patient Appointments</h2><p class="muted">Patient bookings are approved automatically. Click View to see the date, time, service, concern and the teeth the patient marked.</p></div><span class="badge"><?= count($online) ?> total</span></div>
    <div class="r3-table-scroll r3-six-rows">
    <table class="r3-table"><thead><tr><th>Patient</th><th>Schedule</th><th>Service / Reason</th><th>Status</th><th>Dentist</th><th class="r3-actions-col">Action</th></tr></thead><tbody>
    <?php if (!$online): ?><tr><td colspan="6" class="empty">No online bookings yet.</td></tr><?php endif; ?>
    <?php foreach ($online as $a): ?>
        <tr id="appointment-request-<?= (int)$a['id'] ?>"><td><b><?= e($a['first_name'] . ' ' . $a['last_name']) ?></b><small>Patient #<?= e(sd_patient_code($a['patient_no'] ?? 0, $a['patient_id'])) ?></small></td><td><?= e(date('M d, Y', strtotime($a['appointment_date']))) ?><small><?= e(date('h:i A', strtotime($a['appointment_time']))) ?></small></td><td><b><?= e($a['appointment_type']) ?></b><small><?= e($a['reason'] ?: 'No reason provided') ?></small></td><td><span class="status-pill <?= e($a['status']) ?>"><?= e($a['status'] === 'rejected' ? 'Declined' : ucfirst($a['status'])) ?></span></td><td><?= $dentistCell($a) ?></td><td class="r3-actions"><button type="button" class="r3-btn-solid" data-view-appt="<?= (int)$a['id'] ?>">View</button></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
<?php else: ?>
    <div class="r3-card-head"><div><h2>Walk-in Patients</h2><p class="muted">Registered patients who came to the clinic without an online booking.</p></div><?php if ($reqRole === 'assistant'): ?><button type="button" class="btn btn-primary" id="addWalkinBtn"><i class="fa-solid fa-plus"></i> Add Walk-in</button><?php else: ?><span class="badge"><?= count($walkins) ?> total</span><?php endif; ?></div>
    <div class="r3-table-scroll r3-six-rows">
    <table class="r3-table"><thead><tr><th>Patient</th><th>Arrival</th><th>Service / Reason</th><th>Status</th><th>Dentist</th><th class="r3-actions-col">Action</th></tr></thead><tbody>
    <?php if (!$walkins): ?><tr><td colspan="6" class="empty">No walk-in patients recorded yet.</td></tr><?php endif; ?>
    <?php foreach ($walkins as $a): $ws = $a['status'] === 'cancelled' ? '' : ($a['walkin_status'] ?: 'waiting'); ?>
        <tr><td><b><?= e($a['first_name'] . ' ' . $a['last_name']) ?></b><small>Patient #<?= e(sd_patient_code($a['patient_no'] ?? 0, $a['patient_id'])) ?></small></td><td><?= e(date('M d, Y', strtotime($a['appointment_date']))) ?><small><?= e(date('h:i A', strtotime($a['appointment_time']))) ?> · arrived</small></td><td><b><?= e($a['appointment_type']) ?></b><small><?= e($a['reason'] ?: 'No reason provided') ?></small></td><td><?php if ($ws): ?><span class="status-pill walkin-<?= e($ws) ?>"><?= e($walkLabels[$ws] ?? ucfirst($ws)) ?></span><?php else: ?><span class="status-pill cancelled">Cancelled</span><?php endif; ?></td><td><?= $dentistCell($a) ?></td><td class="r3-actions"><button type="button" class="r3-btn-solid" data-view-appt="<?= (int)$a['id'] ?>">View</button></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
<?php endif; ?>
</section>
<?php if ($reqRole === 'assistant'): ?>
<div class="sd-modal" id="walkinModal" role="dialog" aria-modal="true" aria-labelledby="walkinTitle" aria-hidden="true">
    <form method="post" class="sd-modal-dialog r3-walkin-dialog" id="walkinForm">
        <button type="button" class="sd-modal-close" data-close-walkin aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
        <span class="profile-dialog-icon"><i class="fa-solid fa-person-walking"></i></span>
        <h2 id="walkinTitle">Add Walk-in Patient</h2>
        <p class="muted">For a registered patient who arrived at the clinic without an online booking.</p>
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="walkin">
        <div class="r3-form-grid">
            <div class="field full"><label for="wPatient">Patient *</label><select id="wPatient" name="patient_id" required><option value="">Select registered patient</option><?php foreach ($patients as $p): ?><option value="<?= (int)$p['id'] ?>"><?= e($p['last_name'] . ', ' . $p['first_name'] . ' — #' . sd_patient_code($p['patient_no'] ?? 0, $p['id'])) ?></option><?php endforeach; ?></select></div>
            <div class="field"><label for="wDate">Arrival date *</label><input type="date" id="wDate" name="appointment_date" value="<?= e(date('Y-m-d')) ?>" required></div>
            <div class="field"><label for="wTime">Arrival time *</label><input type="time" id="wTime" name="appointment_time" value="<?= e(date('H:i')) ?>" required></div>
            <div class="field"><label for="wService">Service *</label><select id="wService" name="appointment_type" required><option value="">Select service</option><?php foreach ($services as $s): ?><option><?= e($s) ?></option><?php endforeach; ?></select></div>
            <div class="field"><label for="wDentist">Dentist</label><select id="wDentist" name="dentist_id"><option value="0">Not assigned yet</option><?php foreach ($dentists as $d): ?><option value="<?= (int)$d['id'] ?>"><?= e($d['first_name'] . ' ' . $d['last_name']) ?></option><?php endforeach; ?></select></div>
            <div class="field"><label for="wStatus">Status</label><select id="wStatus" name="walkin_status"><option value="waiting">Waiting</option><option value="in_chair">In chair</option></select></div>
            <div class="field full"><label for="wReason">Reason / Concern</label><input id="wReason" name="reason" maxlength="255" placeholder="e.g. Pain on lower left molar"></div>
        </div>
        <div class="profile-dialog-actions"><button type="button" class="btn btn-secondary" data-close-walkin>Cancel</button><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Record Walk-in</button></div>
    </form>
</div>
<script>
(() => {
    const modal = document.getElementById('walkinModal'), btn = document.getElementById('addWalkinBtn');
    const open = () => { modal.classList.add('is-open'); modal.setAttribute('aria-hidden', 'false'); document.getElementById('wPatient').focus(); };
    const close = () => { modal.classList.remove('is-open'); modal.setAttribute('aria-hidden', 'true'); };
    btn?.addEventListener('click', open);
    modal.querySelectorAll('[data-close-walkin]').forEach(b => b.addEventListener('click', close));
    modal.addEventListener('click', e => { if (e.target === modal) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('is-open')) close(); });
    // The dentist is optional; a walk-in with no dentist yet is "Waiting".
    const ds = document.getElementById('wDentist'), ws = document.getElementById('wStatus');
    ds.addEventListener('change', () => { if (ds.value === '0') ws.value = 'waiting'; });
    if (new URLSearchParams(location.search).get('add') === '1') open();
})();
</script>
<?php endif; ?>
