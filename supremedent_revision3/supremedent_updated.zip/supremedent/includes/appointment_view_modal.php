<?php
/**
 * Shared "View appointment" pop-up for the assistant and dentist portals (revision 3).
 * Left: date, time, dental service, dentist, reason / concern and the teeth the patient marked.
 * Right: the 3D odontogram with the marked teeth highlighted.
 * Walk-ins also show their queue status; with $viewModalWalkinForm the assistant can update it here.
 *
 * Usage: require once, then call openAppointmentView(data) where data comes from sd_appointment_view_data().
 */
$viewModalWalkinForm = $viewModalWalkinForm ?? false;
$viewModalDentists = $viewModalDentists ?? [];
?>
<div class="sd-modal" id="apptViewModal" role="dialog" aria-modal="true" aria-labelledby="apptViewTitle" aria-hidden="true">
    <div class="sd-modal-dialog appt-view-dialog r3-appt-view">
        <div class="r3-av-info">
            <div class="appt-view-head"><span class="appt-view-icon"><i class="fa-regular fa-calendar-check"></i></span><div><h2 id="apptViewTitle">Appointment</h2><p class="muted" data-av-patient></p></div><span class="status-pill" data-av-status></span></div>
            <dl class="appt-view-grid">
                <div><dt>Date</dt><dd data-av-date></dd></div>
                <div><dt>Time</dt><dd data-av-time></dd></div>
                <div><dt>Dental Service</dt><dd data-av-service></dd></div>
                <div><dt>Dentist</dt><dd data-av-dentist></dd></div>
                <div class="wide"><dt>Reason / Concern</dt><dd data-av-reason></dd></div>
                <div class="wide" data-av-cancel-wrap hidden><dt>Cancellation</dt><dd data-av-cancel></dd></div>
            </dl>
            <div class="appt-view-teeth">
                <div class="appt-view-teeth-head"><b>Teeth marked by the patient</b><span data-av-teeth-list></span></div>
                <div class="mini-arch" data-av-arch></div>
            </div>
            <?php if ($viewModalWalkinForm): ?>
            <form method="post" class="r3-walkin-update" data-av-walkin hidden>
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="walkin_update"><input type="hidden" name="appointment_id" data-av-walkin-id>
                <div class="field"><label for="avWalkinStatus">Walk-in status</label><select id="avWalkinStatus" name="walkin_status"><option value="waiting">Waiting</option><option value="in_chair">In chair</option><option value="completed">Completed</option></select></div>
                <div class="field"><label for="avWalkinDentist">Dentist</label><select id="avWalkinDentist" name="dentist_id"><option value="0">Not assigned</option><?php foreach ($viewModalDentists as $d): ?><option value="<?= (int)$d['id'] ?>"><?= e($d['first_name'] . ' ' . $d['last_name']) ?></option><?php endforeach; ?></select></div>
                <button type="submit" class="btn btn-primary btn-sm">Save</button>
            </form>
            <?php endif; ?>
        </div>
        <div class="r3-av-model">
            <div class="r3-av-model-head"><span><i class="fa-solid fa-tooth"></i> 3D Odontogram</span><div><button type="button" class="r3-mini-btn" data-av-reset><i class="fa-solid fa-rotate-left"></i> Reset view</button><button type="button" class="sd-modal-close static" data-appt-view-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div></div>
            <div class="r3-av-stage" id="apptViewModel"><span>Loading dental model...</span></div>
            <small class="r3-av-hint">Drag to rotate · scroll to zoom</small>
        </div>
    </div>
</div>
<script>
(() => {
    const modal = document.getElementById('apptViewModal');
    const q = s => modal.querySelector(s);
    const upper = ['18','17','16','15','14','13','12','11','21','22','23','24','25','26','27','28'];
    const lower = ['48','47','46','45','44','43','42','41','31','32','33','34','35','36','37','38'];
    const labels = { pending: 'Pending', approved: 'Approved', completed: 'Completed', rejected: 'Declined', cancelled: 'Cancelled' };
    const walkLabels = { waiting: 'Waiting', in_chair: 'In chair', completed: 'Completed' };
    window.apptViewTeeth = new Set();
    function close() { modal.classList.remove('is-open'); modal.setAttribute('aria-hidden', 'true'); }
    window.openAppointmentView = a => {
        if (!a) return;
        const walkin = a.source === 'walkin';
        q('#apptViewTitle').textContent = a.service || 'Appointment';
        q('[data-av-patient]').textContent = a.patient + ' · Patient #' + (a.patient_code || a.patient_id) + (walkin ? ' · Walk-in' : '');
        const st = q('[data-av-status]');
        const ws = walkin && a.status !== 'cancelled' ? (a.walkin_status || 'waiting') : '';
        st.className = 'status-pill ' + (ws ? 'walkin-' + ws : a.status); st.textContent = ws ? walkLabels[ws] : (labels[a.status] || a.status);
        q('[data-av-date]').textContent = a.date;
        q('[data-av-time]').textContent = a.time + (walkin ? ' · arrived' : '');
        q('[data-av-service]').textContent = a.service;
        q('[data-av-dentist]').textContent = a.dentist || 'Not assigned';
        q('[data-av-reason]').textContent = a.reason || 'No reason provided.';
        q('[data-av-cancel-wrap]').hidden = a.status !== 'cancelled';
        q('[data-av-cancel]').textContent = a.cancel_reason || 'No reason given.';
        const teeth = a.teeth || [];
        q('[data-av-teeth-list]').textContent = teeth.length ? teeth.join(', ') : 'No teeth marked';
        q('[data-av-teeth-list]').classList.toggle('none', !teeth.length);
        const arch = q('[data-av-arch]'); arch.replaceChildren();
        [upper, lower].forEach(row => { const r = document.createElement('div'); r.className = 'mini-arch-row'; row.forEach(t => { const s = document.createElement('span'); s.textContent = t; if (teeth.includes(t)) s.className = 'on'; r.append(s); }); arch.append(r); });
        const wf = q('[data-av-walkin]');
        if (wf) { wf.hidden = !walkin || a.status === 'cancelled'; q('[data-av-walkin-id]').value = a.id; q('#avWalkinStatus').value = a.walkin_status || 'waiting'; q('#avWalkinDentist').value = String(a.dentist_id || 0); }
        window.apptViewTeeth = new Set(teeth);
        modal.classList.add('is-open'); modal.setAttribute('aria-hidden', 'false');
        window.dispatchEvent(new Event('appt-view-open'));
    };
    q('[data-appt-view-close]').addEventListener('click', close);
    modal.addEventListener('click', e => { if (e.target === modal) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('is-open')) close(); });
})();
</script>
<script type="importmap">{"imports":{"three":"../assets/js/three.module.js"}}</script>
<script type="module">
import { createToothViewer } from '../assets/js/tooth_viewer.js';
let viewer = null;
// The model is created the first time the pop-up is visible, so it can size itself; later opens recolor it.
window.addEventListener('appt-view-open', () => requestAnimationFrame(() => {
    if (!viewer) viewer = createToothViewer(document.getElementById('apptViewModel'), { colorFor: id => window.apptViewTeeth.has(id) ? 0x2676db : null, interactive: false });
    else { viewer.sync(); viewer.reset(); }
}));
document.querySelector('[data-av-reset]').addEventListener('click', () => viewer?.reset());
</script>
