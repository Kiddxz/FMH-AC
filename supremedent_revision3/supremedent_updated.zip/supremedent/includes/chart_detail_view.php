<?php
/**
 * Read-only "Dental Chart" view (revision 3): chart details, 3D model, dental health status,
 * oral health condition, tooth count, soft tissue / periodontal / occlusion exams, recommendations
 * and clinical notes. Used by the patient's Dental Records and by the assistant / dentist patient pages.
 */
require_once __DIR__ . '/exam_record.php';
require_once __DIR__ . '/record_helpers.php';

/** Loads one chart (optionally only if it belongs to $patientId) with its teeth, exam record and labels. */
function sd_load_chart(mysqli $conn, int $chartId, int $patientId = 0): ?array
{
    $sql = "SELECT c.*, d.first_name dentist_first, d.last_name dentist_last, cr.first_name creator_first, cr.last_name creator_last
        FROM dental_charts c LEFT JOIN users d ON d.id=c.dentist_id LEFT JOIN users cr ON cr.id=COALESCE(c.created_by,c.dentist_id) WHERE c.id=?" . ($patientId ? ' AND c.patient_id=?' : '') . ' LIMIT 1';
    $st = $conn->prepare($sql);
    if ($patientId) $st->bind_param('ii', $chartId, $patientId); else $st->bind_param('i', $chartId);
    $st->execute();
    $chart = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$chart) return null;
    $teeth = [];
    $st = $conn->prepare('SELECT tooth_number, condition_name FROM dental_chart_teeth WHERE chart_id=?');
    $st->bind_param('i', $chartId);
    $st->execute();
    foreach ($st->get_result()->fetch_all(MYSQLI_ASSOC) as $t) $teeth[(string)$t['tooth_number']] = $t['condition_name'];
    $st->close();
    $data = json_decode($chart['examination_data'] ?: '{}', true);
    $chart['meta'] = sd_chart_meta($conn, $chart);
    $chart['teeth'] = $teeth;
    $chart['record'] = exam_record_normalize(is_array($data) ? $data : []);
    $chart['dentist_name'] = trim(($chart['dentist_first'] ?? '') . ' ' . ($chart['dentist_last'] ?? ''));
    $chart['creator_name'] = trim(($chart['creator_first'] ?? '') . ' ' . ($chart['creator_last'] ?? ''));
    return $chart;
}

/** Every chart of a patient, newest first, with service / time / dentist labels for the lists. */
function sd_patient_charts(mysqli $conn, int $patientId): array
{
    $st = $conn->prepare("SELECT c.id,c.patient_id,c.chart_date,c.chart_time,c.service,c.created_at,c.dentist_id,d.first_name dentist_first,d.last_name dentist_last,cr.first_name creator_first,cr.last_name creator_last,
            (SELECT COUNT(*) FROM dental_chart_teeth t WHERE t.chart_id=c.id) marked
        FROM dental_charts c LEFT JOIN users d ON d.id=c.dentist_id LEFT JOIN users cr ON cr.id=COALESCE(c.created_by,c.dentist_id) WHERE c.patient_id=? ORDER BY COALESCE(c.chart_date,DATE(c.created_at)) DESC, c.chart_time DESC, c.id DESC");
    $st->bind_param('i', $patientId);
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
    foreach ($rows as &$r) {
        $r['meta'] = sd_chart_meta($conn, $r);
        $r['dentist_name'] = trim(($r['dentist_first'] ?? '') . ' ' . ($r['dentist_last'] ?? ''));
        $r['creator_name'] = trim(($r['creator_first'] ?? '') . ' ' . ($r['creator_last'] ?? ''));
    }
    unset($r);
    return $rows;
}

function sd_dr_name(string $name): string
{
    $name = trim($name);
    return $name === '' ? 'Not assigned' : (stripos($name, 'dr.') === 0 ? $name : 'Dr. ' . $name);
}

/** Renders the chart. Call sd_chart_detail_scripts() once afterwards for the 3D model. */
function sd_render_chart_detail(array $chart): void
{
    $rec = $chart['record'];
    $teeth = $chart['teeth'];
    $meta = $chart['meta'];
    $abbr = ['Caries' => 'C', 'Filled' => 'F', 'Missing' => 'M', 'Fractured' => 'Fx', 'Healthy' => '', 'Marked' => '•'];
    $circle = static function (string $n) use ($teeth, $abbr): string {
        $c = $teeth[$n] ?? '';
        return '<span class="r3-tc ' . e(strtolower($c)) . '" title="' . e($n . ($c ? ' — ' . $c : '')) . '">' . e($abbr[$c] ?? '') . '</span>';
    };
    $marked = array_filter($teeth, static fn($c) => $c !== 'Healthy');
    $order = array_merge(SD_FDI_UPPER, SD_FDI_LOWER);
    uksort($marked, static fn($a, $b) => array_search((string)$a, $order, true) <=> array_search((string)$b, $order, true));
    $chip = static fn(string $label, bool $on) => '<span class="r3-chip' . ($on ? ' on' : '') . '">' . ($on ? '&#10003; ' : '') . e($label) . '</span>';
    $yn = static function (array $pair): string {
        $out = '';
        foreach ([0, 1] as $i) foreach (['Y', 'N'] as $v) $out .= '<span class="r3-yn' . ($pair[$i] === $v ? ' on' : '') . '">' . $v . '</span>';
        return '<span class="r3-yn-group">' . $out . '</span>';
    };
    $dash = static fn($v) => $v === '' || $v === null ? '<span class="r3-dash">—</span>' : e($v);
    ?>
<section class="r3-card r3-chart-details">
  <h3 class="r3-section-label">Chart Details</h3>
  <div class="r3-detail-grid">
    <div><span>Date of examination</span><b><?= e(date('M d, Y', strtotime($meta['date']))) ?><?= $meta['time'] ? ' · ' . e(date('g:i A', strtotime($meta['time']))) : '' ?></b></div>
    <div><span>Service</span><b><?= e($meta['service']) ?></b></div>
    <div><span>Dentist</span><b><?= e(sd_dr_name($chart['dentist_name'])) ?></b></div>
    <div><span>Charted by</span><b><?= e($chart['creator_name'] !== '' ? $chart['creator_name'] : 'Clinic staff') ?></b></div>
  </div>
</section>
<div class="r3-chart-row">
  <section class="r3-card r3-chart-model">
    <div class="r3-card-head"><h3 class="r3-section-label">3D Model</h3><div class="r3-model-tools"><button type="button" class="r3-mini-btn" data-chart-view="reset"><i class="fa-solid fa-rotate-left"></i> Reset view</button><button type="button" class="r3-mini-btn" data-chart-view="upper">Upper</button><button type="button" class="r3-mini-btn" data-chart-view="lower">Lower</button></div></div>
    <div class="r3-model-stage" id="chartDetailModel" data-teeth="<?= e(json_encode((object)$teeth)) ?>"><span>Loading dental model...</span><small class="r3-model-hint">Drag to rotate · scroll to zoom</small></div>
  </section>
  <section class="r3-card r3-chart-status">
    <h3 class="r3-section-label">Dental Health Status</h3>
    <div class="r3-tooth-grid">
      <?php foreach (SD_FDI_UPPER as $n) echo $circle($n); ?>
      <?php foreach (SD_FDI_UPPER as $n): ?><b class="r3-tn"><?= $n ?></b><?php endforeach; ?>
      <?php foreach (SD_FDI_LOWER as $n): ?><b class="r3-tn"><?= $n ?></b><?php endforeach; ?>
      <?php foreach (SD_FDI_LOWER as $n) echo $circle($n); ?>
    </div>
    <p class="r3-tooth-legend">C = Caries · F = Filled · M = Missing · Fx = Fractured</p>
    <div class="r3-marked-summary<?= $marked ? '' : ' none' ?>"><?php if ($marked): ?><b><?= count($marked) ?> <?= count($marked) === 1 ? 'tooth' : 'teeth' ?> marked:</b> <?= e(implode(', ', array_map(static fn($t, $c) => $t . ' — ' . $c, array_keys($marked), $marked))) ?><?php else: ?>No teeth marked on this chart.<?php endif; ?></div>
  </section>
</div>
<div class="r3-chart-row">
  <div class="r3-chart-col">
    <section class="r3-card">
      <h3 class="r3-section-label">Oral Health Condition</h3>
      <table class="r3-kv"><tbody>
        <tr><th>Date of examination</th><td><b><?= e(date('M d, Y', strtotime($meta['date']))) ?></b></td></tr>
        <tr><th>Age last birthday</th><td><b><?= $dash($rec['age_last_birthday']) ?></b></td></tr>
        <?php foreach (EXAM_ORAL_ROWS as $k => $label): ?><tr><th><?= e(ucfirst(strtolower($label))) ?></th><td><?= $yn($rec['oral'][$k]) ?></td></tr><?php endforeach; ?>
        <tr><th>Dentofacial anomaly, neoplasm, others</th><td><?= $dash($rec['dentofacial']) ?></td></tr>
      </tbody></table>
    </section>
    <section class="r3-card">
      <h3 class="r3-section-label">Tooth Count</h3>
      <table class="r3-count-table"><thead><tr><th></th><th>T</th><th>P</th><th>T</th><th>P</th></tr></thead><tbody>
        <?php foreach (EXAM_TOOTH_COUNT_ROWS as $k => $label): ?><tr><th><?= e(str_replace(['df & dmf', ' & '], ['df and DMF', ' and '], ucfirst(strtolower($label)))) ?></th><?php foreach ($rec['tooth_count'][$k] as $v): ?><td><?= $dash($v) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
      </tbody></table>
    </section>
  </div>
  <div class="r3-chart-col">
    <section class="r3-card">
      <h3 class="r3-section-label">Initial Soft Tissue Exam</h3>
      <div class="r3-chips"><?php foreach (EXAM_SOFT_TISSUE as $item) echo $chip(str_replace('&', 'and', $item), in_array($item, $rec['soft_tissue'], true)); ?></div>
    </section>
    <section class="r3-card">
      <h3 class="r3-section-label">Initial Periodontal Exam</h3>
      <table class="r3-kv r3-perio"><tbody>
        <?php foreach (EXAM_PERIO_ROWS as $k => [$label, $options]): ?><tr><th><?= e(strtoupper($label)) ?></th><td><div class="r3-chips"><?php foreach ($options as $opt) echo $chip($opt, $rec['perio'][$k] === $opt); ?></div></td></tr><?php endforeach; ?>
        <tr><th>MUCOGINGIVAL DEFECTS</th><td><?= $dash($rec['mucogingival']) ?></td></tr>
        <tr><th>CLINICAL DATA</th><td><?= $dash($rec['clinical_data']) ?></td></tr>
      </tbody></table>
    </section>
    <section class="r3-card">
      <h3 class="r3-section-label">Occlusion and T.M.J. Exam</h3>
      <table class="r3-kv r3-perio"><tbody>
        <tr><th>OCCLUSION</th><td><div class="r3-chips"><?php foreach (EXAM_OCCLUSION as $opt) echo $chip($opt, $rec['occlusion'] === $opt); ?></div></td></tr>
        <tr><th>T.M.J. EXAM</th><td><div class="r3-chips"><?php foreach (EXAM_TMJ as $opt) echo $chip($opt, in_array($opt, $rec['tmj'], true)); ?></div></td></tr>
      </tbody></table>
    </section>
  </div>
</div>
<section class="r3-card">
  <h3 class="r3-section-label">Conditions and Recommendations</h3>
  <div class="r3-recommend">
    <?php foreach ([EXAM_RECOMMEND_LEFT, EXAM_RECOMMEND_RIGHT] as $column): ?><div><?php foreach ($column as $value => $label): $on = in_array($value, $rec['recommendations'], true); ?><p class="<?= $on ? 'on' : '' ?>"><span class="r3-check"><?= $on ? '&#10003;' : '' ?></span><?= e($label) ?><?php if ($value === 'Others' && $rec['others'] !== ''): ?>: <b><?= e($rec['others']) ?></b><?php endif; ?></p><?php endforeach; ?></div><?php endforeach; ?>
  </div>
</section>
<section class="r3-card">
  <h3 class="r3-section-label">Clinical Notes</h3>
  <p class="r3-notes"><?= trim((string)$chart['notes']) !== '' ? nl2br(e($chart['notes'])) : '<span class="r3-dash">No clinical notes.</span>' ?></p>
</section>
    <?php
}

/** 3D model for the chart view: marked teeth are colored by condition. */
function sd_chart_detail_scripts(): void
{
    ?>
<script type="importmap">{"imports":{"three":"../assets/js/three.module.js"}}</script>
<script type="module">
import { createToothViewer } from '../assets/js/tooth_viewer.js';
const holder = document.getElementById('chartDetailModel');
if (holder) {
    const teeth = JSON.parse(holder.dataset.teeth || '{}');
    const colors = { Caries: 0xdf5656, Filled: 0x2676db, Missing: 0x64748b, Fractured: 0xd69325, Marked: 0x2676db };
    const hint = holder.querySelector('.r3-model-hint');
    const viewer = createToothViewer(holder, { colorFor: id => colors[teeth[id]] ?? null, interactive: false });
    if (hint) holder.append(hint);
    document.querySelectorAll('[data-chart-view]').forEach(b => b.addEventListener('click', () => {
        document.querySelectorAll('[data-chart-view]').forEach(x => x.classList.toggle('active', x === b && b.dataset.chartView !== 'reset'));
        b.dataset.chartView === 'reset' ? viewer.reset() : viewer.setView(b.dataset.chartView);
    }));
}
</script>
    <?php
}
