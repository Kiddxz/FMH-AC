<?php
/**
 * "Today's schedule" pop-up shown to a dentist right after signing in (revision 3).
 * Lists today's patients and the next clinic day's patients (the dentist's own and unassigned bookings),
 * with Open chart, Close, Open calendar and "Don't show again today".
 */
require_once __DIR__ . '/record_helpers.php';
$uid = (int)$_SESSION['user_id'];
$todayKey = date('Y-m-d');
$next = new DateTimeImmutable('tomorrow');
if ($next->format('w') === '0') $next = $next->modify('+1 day'); // the clinic is closed on Sundays
$nextKey = $next->format('Y-m-d');
$isTomorrow = $nextKey === date('Y-m-d', strtotime('+1 day'));
$load = static function (string $day) use ($conn, $uid): array {
    $st = $conn->prepare("SELECT a.id,a.patient_id,a.appointment_time,a.appointment_type,a.status,a.source,u.first_name,u.last_name FROM appointments a JOIN users u ON u.id=a.patient_id WHERE a.appointment_date=? AND a.status IN ('approved','completed') AND (a.dentist_id=? OR a.dentist_id IS NULL) ORDER BY a.appointment_time");
    $st->bind_param('si', $day, $uid);
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
    return $rows;
};
$todayRows = $load($todayKey);
$nextRows = $load($nextKey);
$hour = (int)date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
$row = static function (array $a): string {
    $t = strtotime($a['appointment_time']);
    $status = $a['status'] === 'completed' ? 'Completed' : 'Confirmed';
    return '<li class="r3-sp-row"><time><b>' . e(date('g:i', $t)) . '</b><small>' . e(date('A', $t)) . '</small></time><span class="r3-avatar sm">' . e(sd_initials($a['first_name'], $a['last_name'])) . '</span>'
        . '<span class="r3-sp-name"><b>' . e($a['first_name'] . ' ' . $a['last_name']) . '</b><small>' . e($a['appointment_type']) . (($a['source'] ?? '') === 'walkin' ? ' · Walk-in' : '') . '</small></span>'
        . '<span class="status-pill ' . ($a['status'] === 'completed' ? 'completed' : 'approved') . '">' . $status . '</span><a class="r3-back" href="patient_record.php?id=' . (int)$a['patient_id'] . '">Open chart</a></li>';
};
?>
<div class="sd-modal r3-schedule-popup" id="schedulePopup" role="dialog" aria-modal="true" aria-labelledby="schedulePopupTitle" aria-hidden="true" data-day="<?= e($todayKey) ?>">
    <div class="sd-modal-dialog r3-sp-dialog">
        <div class="r3-sp-head">
            <span class="r3-eyebrow">Today's schedule</span>
            <h2 id="schedulePopupTitle"><?= e($greeting) ?>, Dr. <?= e($_SESSION['first_name'] ?? '') ?></h2>
            <p><?= e(date('l, M j, Y')) ?></p>
            <button type="button" class="sd-modal-close" data-sp-close aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="r3-sp-body">
            <?php if (!$todayRows): ?>
                <div class="r3-sp-empty"><span><i class="fa-regular fa-calendar-check"></i></span><b>No patients scheduled today</b><small>Walk-ins will appear here once the assistant records them.</small></div>
            <?php else: ?>
                <h3 class="r3-sp-label">Today · <?= count($todayRows) ?> patient<?= count($todayRows) === 1 ? '' : 's' ?></h3>
                <ul class="r3-sp-list r3-sp-today"><?php foreach ($todayRows as $a) echo $row($a); ?></ul>
            <?php endif; ?>
            <h3 class="r3-sp-label"><?= $isTomorrow ? 'Coming up tomorrow' : 'Next clinic day' ?> · <?= e(strtoupper($next->format('D, M j'))) ?></h3>
            <?php if (!$nextRows): ?><p class="r3-sp-none">No patients scheduled yet.</p><?php else: ?>
                <ul class="r3-sp-list"><?php foreach (array_slice($nextRows, 0, 2) as $a) echo $row($a); ?></ul>
                <?php if (count($nextRows) > 2): ?><a class="r3-sp-more" href="appointments.php">+ <?= count($nextRows) - 2 ?> more <?= $isTomorrow ? 'tomorrow' : 'on ' . e($next->format('D, M j')) ?></a><?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="r3-sp-foot">
            <label><input type="checkbox" id="spHideToday"> Don't show again today</label>
            <div><button type="button" class="btn btn-secondary" data-sp-close>Close</button><a class="btn btn-primary" href="appointments.php" data-sp-calendar>Open calendar</a></div>
        </div>
    </div>
</div>
<script>
(() => {
    const m = document.getElementById('schedulePopup'), day = m.dataset.day, KEY = 'sd-schedule-popup-hidden';
    let hidden = ''; try { hidden = localStorage.getItem(KEY) || ''; } catch (_) {}
    if (hidden === day) return;
    const remember = () => { if (document.getElementById('spHideToday').checked) { try { localStorage.setItem(KEY, day); } catch (_) {} } };
    const close = () => { remember(); m.classList.remove('is-open'); m.setAttribute('aria-hidden', 'true'); };
    m.querySelectorAll('[data-sp-close]').forEach(b => b.addEventListener('click', close));
    m.querySelector('[data-sp-calendar]').addEventListener('click', remember);
    m.addEventListener('click', e => { if (e.target === m) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && m.classList.contains('is-open')) close(); });
    m.classList.add('is-open'); m.setAttribute('aria-hidden', 'false');
})();
</script>
