<?php
/**
 * First sign-in password change (revision 3).
 * Accounts created by the assistant (Register Patient) get a random temporary password by email and
 * users.must_change_password = 1. Until the patient sets their own password this pop-up stays on every
 * patient page and cannot be closed.
 */
$sdMustChange = false;
$sdUid = (int)($_SESSION['user_id'] ?? 0);
if ($sdUid && isset($conn)) {
    try {
        $st = $conn->prepare('SELECT must_change_password FROM users WHERE id=? LIMIT 1');
        $st->bind_param('i', $sdUid);
        $st->execute();
        $sdMustChange = (int)($st->get_result()->fetch_assoc()['must_change_password'] ?? 0) === 1;
        $st->close();
    } catch (Throwable $e) { $sdMustChange = false; }
}
if (!$sdMustChange || basename($_SERVER['SCRIPT_NAME'] ?? '') === 'change_password.php') return;
?>
<div class="sd-modal is-open force-pass-modal" id="forcePasswordModal" role="dialog" aria-modal="true" aria-labelledby="forcePassTitle" aria-hidden="false">
    <form class="sd-modal-dialog sd-modal-small force-pass-dialog" id="forcePasswordForm" novalidate>
        <span class="profile-dialog-icon"><i class="fa-solid fa-key"></i></span>
        <h2 id="forcePassTitle">Change your password</h2>
        <p class="muted">Your account was created by the clinic with a temporary password. Please set your own password to continue.</p>
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="forced" value="1"><input type="hidden" name="ajax" value="1">
        <div class="field"><label for="fpNew">New Password</label><input type="password" id="fpNew" name="new_password" minlength="8" maxlength="128" autocomplete="new-password" required></div>
        <div class="field"><label for="fpConfirm">Confirm New Password</label><input type="password" id="fpConfirm" name="confirm_password" minlength="8" maxlength="128" autocomplete="new-password" required></div>
        <ul class="force-pass-rules" id="fpRules">
            <li data-rule="len">At least 8 characters</li><li data-rule="upper">An uppercase letter</li><li data-rule="lower">A lowercase letter</li><li data-rule="num">A number</li><li data-rule="sym">A special character</li>
        </ul>
        <div class="field-hint error" id="fpError" role="alert"></div>
        <div class="profile-dialog-actions"><button type="submit" class="btn btn-primary" id="fpSubmit"><i class="fa-solid fa-floppy-disk"></i> Save New Password</button></div>
    </form>
</div>
<script>
(() => {
    const form = document.getElementById('forcePasswordForm'), err = document.getElementById('fpError'), btn = document.getElementById('fpSubmit');
    const np = document.getElementById('fpNew'), cp = document.getElementById('fpConfirm');
    const rules = { len: v => v.length >= 8, upper: v => /[A-Z]/.test(v), lower: v => /[a-z]/.test(v), num: v => /\d/.test(v), sym: v => /[^A-Za-z0-9]/.test(v) };
    const paint = () => document.querySelectorAll('#fpRules li').forEach(li => li.classList.toggle('ok', rules[li.dataset.rule](np.value)));
    np.addEventListener('input', paint); paint();
    document.body.classList.add('force-pass-open');
    // Other page scripts close open pop-ups on Escape; this one has to stay until the password is changed.
    const modal = document.getElementById('forcePasswordModal');
    new MutationObserver(() => { if (!modal.classList.contains('is-open')) { modal.classList.add('is-open'); modal.setAttribute('aria-hidden', 'false'); } }).observe(modal, { attributes: true, attributeFilter: ['class'] });
    setTimeout(() => np.focus(), 60);
    form.addEventListener('submit', async e => {
        e.preventDefault(); err.textContent = '';
        if (!Object.values(rules).every(r => r(np.value))) { err.textContent = 'Your new password does not meet all of the requirements.'; np.focus(); return; }
        if (np.value !== cp.value) { err.textContent = 'Passwords do not match.'; cp.focus(); return; }
        btn.disabled = true;
        try {
            const res = await fetch('change_password.php', { method: 'POST', credentials: 'same-origin', headers: { Accept: 'application/json' }, body: new FormData(form) });
            const data = await res.json().catch(() => ({ ok: false, message: 'Unexpected server response. Please try again.' }));
            if (!data.ok) throw new Error(data.message || 'Unable to change the password.');
            location.reload();
        } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
    });
})();
</script>
