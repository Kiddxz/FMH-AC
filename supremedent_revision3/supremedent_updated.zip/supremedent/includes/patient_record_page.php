<?php
/**
 * One patient's records for the assistant and dentist portals (revision 3).
 * Tabs: Dental Record (charts -> full chart), Treatment Plan Record (plans -> Removable / Fixed records -> plan),
 * Appointment Record (every appointment with the View pop-up).
 * Expects $recordRole ('assistant'|'dentist').
 */
require_once __DIR__ . '/chart_detail_view.php';
require_once __DIR__ . '/restoration_detail_view.php';
require_once __DIR__ . '/appointment_helpers.php';
$recordRole = ($recordRole ?? '') === 'dentist' ? 'dentist' : 'assistant';
$uid = (int)$_SESSION['user_id'];
$patientId = (int)($_GET['id'] ?? 0);
$patient = sd_load_patient($conn, $patientId);
if (!$patient) { header('Location: patients.php'); exit; }
$tab = in_array($_GET['tab'] ?? '', ['dental', 'plans', 'appointments'], true) ? $_GET['tab'] : 'dental';
$self = 'patient_record.php?id=' . $patientId;
$name = $patient['first_name'] . ' ' . $patient['last_name'];

$chart = null; $plan = null; $order = null; $type = ($_GET['type'] ?? '') === 'fixed' ? 'fixed' : 'removable';
$charts = []; $plans = []; $records = []; $appointments = [];
if ($tab === 'dental') {
    if ((int)($_GET['chart'] ?? 0) > 0) $chart = sd_load_chart($conn, (int)$_GET['chart'], $patientId);
    if (!$chart) $charts = sd_patient_charts($conn, $patientId);
} elseif ($tab === 'plans') {
    if ((int)($_GET['order'] ?? 0) > 0) $order = sd_load_restoration($conn, (int)$_GET['order'], ['patient_id' => $patientId]);
    $plans = sd_patient_treatment_plans($conn, $patientId);
    foreach ($plans as $p) if ((int)$p['id'] === (int)($_GET['plan'] ?? 0)) $plan = $p;
    if ($plan && !$order) $records = sd_plan_restorations($conn, (int)$plan['id'], $type, $patientId);
} else {
    $st = $conn->prepare("SELECT a.*, u.first_name, u.last_name, u.email, d.first_name dentist_first, d.last_name dentist_last FROM appointments a JOIN users u ON u.id=a.patient_id LEFT JOIN users d ON d.id=a.dentist_id WHERE a.patient_id=? ORDER BY a.appointment_date DESC, a.appointment_time DESC");
    $st->bind_param('i', $patientId);
    $st->execute();
    $appointments = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
}

// Restoration plan: shown on its own page, like the Treatment Plans view, with Back to the record list.
if ($order) {
    $back = $self . '&tab=plans' . ($order['treatment_plan_id'] ? '&plan=' . (int)$order['treatment_plan_id'] . '&type=' . $order['restoration_type'] : '');
    $canEdit = $recordRole === 'assistant' || (int)$order['dentist_id'] === $uid;
    require __DIR__ . '/ui.php';
    ui_header(ucfirst($order['restoration_type']) . ' Restoration Plan', $recordRole);
    ui_sidebar($recordRole, 'patient_record.php');
    $crumbs = '<a href="patients.php">Patients</a> / <a href="' . e($self) . '">' . e($name) . '</a> / <a href="' . e($self . '&tab=plans') . '">Treatment Plan Record</a> / <a href="' . e($back) . '">' . e(ucfirst($order['restoration_type'])) . '</a> / Order No. ' . e($order['order_no'] ?: (string)$order['id']);
    sd_render_restoration_detail($order, ['back' => $back, 'edit' => $canEdit ? 'restoration_form.php?id=' . (int)$order['id'] : '', 'crumbs' => $crumbs]);
    sd_restoration_detail_scripts();
    ui_footer();
    return;
}

if ($chart) { $title = 'Dental Chart'; $intro = 'Complete chart recorded on ' . date('M d, Y', strtotime($chart['meta']['date'])) . '.'; $back = $self; }
elseif ($plan) { $title = ucfirst($type) . ' Records'; $intro = 'All ' . $type . ' prosthesis records under the ' . date('M d, Y', strtotime($plan['created_at'])) . ' plan.'; $back = $self . '&tab=plans'; }
elseif ($tab === 'plans') { $title = 'Treatment Plan Record'; $intro = 'All treatment plans for this patient.'; $back = 'patients.php'; }
elseif ($tab === 'appointments') { $title = 'Appointment Record'; $intro = 'Every appointment of this patient, newest first.'; $back = 'patients.php'; }
else { $title = 'Dental Record'; $intro = 'All charts created for this patient.'; $back = 'patients.php'; }
$crumb = ['<a href="patients.php">Patients</a>', '<a href="' . e($self) . '">' . e($name) . '</a>'];
$crumb[] = $tab === 'plans' ? ($plan ? '<a href="' . e($self . '&tab=plans') . '">Treatment Plan Record</a>' : 'Treatment Plan Record') : ($tab === 'appointments' ? 'Appointment Record' : ($chart ? '<a href="' . e($self) . '">Dental Record</a>' : 'Dental Record'));
if ($chart) $crumb[] = e(date('M d, Y', strtotime($chart['meta']['date'])));
if ($plan) $crumb[] = e(ucfirst($type));
$viewData = [];
foreach ($appointments as $a) $viewData[(int)$a['id']] = sd_appointment_view_data($a) + ['patient_code' => $patient['code']];

require __DIR__ . '/ui.php';
ui_header($title . ' · ' . $name, $recordRole);
ui_sidebar($recordRole, 'patient_record.php'); ?>
<nav class="r3-crumbs"><?= implode(' / ', $crumb) ?></nav>
<div class="page-head compact-head r3-tight-head">
    <div>
        <div class="eyebrow">PATIENT MANAGEMENT</div>
        <h1><?= e($title) ?></h1>
        <div class="muted"><?= e($intro) ?></div>
    </div>
</div>
<div class="r3-stack">
<?php sd_render_patient_card($patient, $back); ?>
<nav class="r3-tabs" aria-label="Patient records">
    <a class="<?= $tab === 'dental' ? 'active' : '' ?>" href="<?= e($self) ?>">Dental Record</a>
    <a class="<?= $tab === 'plans' ? 'active' : '' ?>" href="<?= e($self . '&tab=plans') ?>">Treatment Plan Record</a>
    <a class="<?= $tab === 'appointments' ? 'active' : '' ?>" href="<?= e($self . '&tab=appointments') ?>">Appointment Record</a>
</nav>
<?php if ($chart): ?>
    <?php sd_render_chart_detail($chart); ?>
<?php elseif ($tab === 'dental'): ?>
<section class="r3-card" data-live-region="charts">
    <div class="r3-card-head"><h2>Charts created</h2><span class="r3-count"><?= count($charts) ?> record<?= count($charts) === 1 ? '' : 's' ?></span></div>
    <div class="r3-table-scroll" style="--r3-rows-height: 470px">
    <table class="r3-table"><thead><tr><th>Date &amp; Time</th><th>Service</th><th>Dentist</th><th class="r3-actions-col">Actions</th></tr></thead><tbody>
    <?php if (!$charts): ?><tr><td colspan="4" class="empty">No dental charts for this patient yet.</td></tr><?php endif; ?>
    <?php foreach ($charts as $c): ?>
        <tr><td><?= sd_date_time_cell($c['meta']['date'], $c['meta']['time']) ?></td><td><?= e($c['meta']['service']) ?></td><td><?= e(sd_dr_name($c['dentist_name'])) ?></td><td class="r3-actions"><a class="r3-btn-view" href="<?= e($self . '&chart=' . (int)$c['id']) ?>">View</a></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
</section>
<?php elseif ($plan): ?>
<section class="r3-card">
    <div class="r3-card-head"><h2><?= e(ucfirst($type)) ?> records</h2><span class="r3-count"><?= count($records) ?> record<?= count($records) === 1 ? '' : 's' ?></span></div>
    <table class="r3-table"><thead><tr><th>Date &amp; Time</th><th>Service</th><th>Stage</th><th class="r3-actions-col">Actions</th></tr></thead><tbody>
    <?php if (!$records): ?><tr><td colspan="4" class="empty">No <?= e($type) ?> records under this plan yet.</td></tr><?php endif; ?>
    <?php foreach ($records as $r): ?>
        <tr><td><?= sd_date_time_cell($r['date_sent'] ?: $r['created_at'], $r['created_at']) ?></td><td><?= e(sd_restoration_service($r)) ?></td><td><?= e(sd_restoration_stage($r)) ?></td><td class="r3-actions"><a class="r3-btn-view" href="<?= e($self . '&tab=plans&order=' . (int)$r['id']) ?>">View</a></td></tr>
    <?php endforeach; ?>
    </tbody></table>
</section>
<?php elseif ($tab === 'plans'): ?>
<section class="r3-card" data-live-region="plans">
    <div class="r3-card-head"><h2>Treatment plans</h2><span class="r3-count"><?= count($plans) ?> record<?= count($plans) === 1 ? '' : 's' ?></span></div>
    <div class="r3-table-scroll" style="--r3-rows-height: 470px">
    <table class="r3-table"><thead><tr><th>Date &amp; Time</th><th>Service</th><th>Dentist</th><th class="r3-actions-col">Actions</th></tr></thead><tbody>
    <?php if (!$plans): ?><tr><td colspan="4" class="empty">No treatment plans for this patient yet.</td></tr><?php endif; ?>
    <?php foreach ($plans as $p): ?>
        <tr><td><?= sd_date_time_cell($p['created_at'], $p['created_at']) ?></td><td><?= e($p['procedure_name']) ?></td><td><?= e($p['dentist_name'] ? sd_dr_name($p['dentist_name']) : '—') ?></td>
        <td class="r3-actions"><div>
            <a class="r3-plan-btn removable" href="<?= e($self . '&tab=plans&plan=' . (int)$p['id'] . '&type=removable') ?>"><i class="fa-solid fa-teeth-open"></i> Removable<?php if ((int)$p['removable_count']): ?> <span class="r3-mini-count"><?= (int)$p['removable_count'] ?></span><?php endif; ?></a>
            <a class="r3-plan-btn fixed" href="<?= e($self . '&tab=plans&plan=' . (int)$p['id'] . '&type=fixed') ?>"><i class="fa-solid fa-tooth"></i> Fixed<?php if ((int)$p['fixed_count']): ?> <span class="r3-mini-count"><?= (int)$p['fixed_count'] ?></span><?php endif; ?></a>
        </div></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
</section>
<?php else: ?>
<section class="r3-card" data-live-region="appointments">
    <div class="r3-card-head"><h2>Appointments</h2><span class="r3-count"><?= count($appointments) ?> record<?= count($appointments) === 1 ? '' : 's' ?></span></div>
    <div class="r3-table-scroll" style="--r3-rows-height: 470px">
    <table class="r3-table"><thead><tr><th>Date &amp; Time</th><th>Service / Reason</th><th>Type</th><th>Status</th><th>Dentist</th><th class="r3-actions-col">Action</th></tr></thead><tbody>
    <?php if (!$appointments): ?><tr><td colspan="6" class="empty">No appointments for this patient yet.</td></tr><?php endif; ?>
    <?php foreach ($appointments as $a): ?>
        <tr><td><?= sd_date_time_cell($a['appointment_date'], $a['appointment_time']) ?></td><td><b><?= e($a['appointment_type']) ?></b><small><?= e($a['reason'] ?: 'No reason provided') ?></small></td><td><?= ($a['source'] ?? 'online') === 'walkin' ? 'Walk-in' : 'Online booking' ?></td><td><span class="status-pill <?= e($a['status']) ?>"><?= e($a['status'] === 'rejected' ? 'Declined' : ucfirst($a['status'])) ?></span></td><td><?= $a['dentist_first'] ? e($a['dentist_first'] . ' ' . $a['dentist_last']) : '<span class="muted">Not assigned</span>' ?></td><td class="r3-actions"><button type="button" class="r3-btn-solid" data-view-appt="<?= (int)$a['id'] ?>">View</button></td></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
</section>
<?php endif; ?>
</div>
<?php if ($chart) sd_chart_detail_scripts(); ?>
<?php if ($tab === 'appointments'): require __DIR__ . '/appointment_view_modal.php'; ?>
<script>(()=>{const data=<?= json_encode((object)$viewData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;document.querySelectorAll('[data-view-appt]').forEach(b=>b.addEventListener('click',()=>openAppointmentView(data[b.dataset.viewAppt])));})();</script>
<?php endif; ?>
<?php ui_footer(); ?>
