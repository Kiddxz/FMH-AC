<?php
/**
 * Patients list for the assistant and dentist portals (revision 3).
 * Patient numbers are shown as 000001, 000002, ...; the most recently updated patient is listed first
 * (new registration, profile change, appointment, chart or restoration plan). View opens the patient record.
 * Expects $listRole ('assistant'|'dentist').
 */
$listRole = ($listRole ?? '') === 'dentist' ? 'dentist' : 'assistant';
$q = trim($_GET['q'] ?? '');
$like = '%' . $q . '%';
$digits = ltrim(preg_replace('/\D/', '', $q), '0');
$st = $conn->prepare("SELECT u.id,u.first_name,u.last_name,u.email,u.status,u.created_at,u.patient_no,
        GREATEST(u.created_at, COALESCE(p.updated_at,u.created_at),
            COALESCE((SELECT MAX(a.updated_at) FROM appointments a WHERE a.patient_id=u.id), u.created_at),
            COALESCE((SELECT MAX(c.updated_at) FROM dental_charts c WHERE c.patient_id=u.id), u.created_at),
            COALESCE((SELECT MAX(r.updated_at) FROM restoration_orders r WHERE r.patient_id=u.id), u.created_at)) last_update
    FROM users u LEFT JOIN patient_profiles p ON p.user_id=u.id
    WHERE u.role='patient' AND (u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name,' ',u.last_name) LIKE ? OR u.email LIKE ? OR (? <> '' AND u.patient_no = ?))
    ORDER BY last_update DESC, u.id DESC");
$st->bind_param('ssssss', $like, $like, $like, $like, $digits, $digits);
$st->execute();
$rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$st->close();
require __DIR__ . '/ui.php';
ui_header('Patients', $listRole);
ui_sidebar($listRole, 'patients.php'); ?>
<div class="page-head compact-head">
    <div>
        <div class="eyebrow">PATIENT MANAGEMENT</div>
        <h1>Patients</h1>
        <div class="muted">Search and review registered patients.</div>
    </div>
</div>
<section class="r3-card" data-live-region="patients">
    <form class="directory-search r3-search" method="get"><input name="q" value="<?= e($q) ?>" placeholder="Search name, email or patient ID"><button class="btn btn-secondary">Search</button><?php if ($q !== ''): ?><a class="btn btn-secondary" href="patients.php">Clear</a><?php endif; ?></form>
    <div class="r3-table-scroll" style="--r3-rows-height: 520px">
        <table class="r3-table">
            <thead><tr><th>Patient</th><th>Email</th><th>Status</th><th>Registered</th><th class="r3-actions-col">Actions</th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="5" class="empty">No patients matched your search.</td></tr><?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><b><?= e($r['first_name'] . ' ' . $r['last_name']) ?></b><small>ID #<?= e(sd_patient_code($r['patient_no'], $r['id'])) ?></small></td>
                    <td><?= e($r['email']) ?></td>
                    <td><span class="status-pill <?= $r['status'] === 'active' ? 'approved' : 'rejected' ?>"><?= e(ucfirst($r['status'])) ?></span></td>
                    <td><?= e(date('M d, Y', strtotime($r['created_at']))) ?><small>Updated <?= e(date('M d, Y', strtotime($r['last_update']))) ?></small></td>
                    <td class="r3-actions"><a class="r3-btn-solid" href="patient_record.php?id=<?= (int)$r['id'] ?>"><i class="fa-regular fa-eye"></i> View</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php ui_footer(); ?>
