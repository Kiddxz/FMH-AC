<?php
/**
 * Shared helpers for revision 3 (2026-10-16): patient record pages, restoration plan views and lists.
 */

const SD_FDI_UPPER = ['18','17','16','15','14','13','12','11','21','22','23','24','25','26','27','28'];
const SD_FDI_LOWER = ['48','47','46','45','44','43','42','41','31','32','33','34','35','36','37','38'];
const SD_TOOTH_TYPES = [1 => 'central incisor', 2 => 'lateral incisor', 3 => 'canine', 4 => '1st premolar', 5 => '2nd premolar', 6 => '1st molar', 7 => '2nd molar', 8 => '3rd molar'];

/** Metal / pontic designs are stored as a JSON list (revision 3) or a single name (older plans). */
function sd_design_list($value): array
{
    $value = trim((string)$value);
    if ($value === '') return [];
    if ($value[0] === '[') {
        $list = json_decode($value, true);
        return is_array($list) ? array_values(array_filter(array_map('strval', $list), 'strlen')) : [];
    }
    return [$value];
}

function sd_json_list($value): array
{
    $d = json_decode((string)$value ?: '[]', true);
    return is_array($d) ? array_values(array_map('strval', $d)) : [];
}

/** "UR2" style quadrant name for an FDI tooth number. */
function sd_tooth_quadrant(string $fdi): string
{
    $q = ['1' => 'UR', '2' => 'UL', '3' => 'LL', '4' => 'LR'][$fdi[0] ?? ''] ?? '';
    return $q . ($fdi[1] ?? '');
}

/** "upper right lateral incisor" for tooth 12. */
function sd_tooth_long_name(string $fdi): string
{
    $side = ['1' => 'upper right', '2' => 'upper left', '3' => 'lower left', '4' => 'lower right'][$fdi[0] ?? ''] ?? '';
    return trim($side . ' ' . (SD_TOOTH_TYPES[(int)($fdi[1] ?? 0)] ?? 'tooth'));
}

/** Short plain-language summary of the selected teeth, e.g. "Third molars, all four quadrants". */
function sd_teeth_summary(array $teeth): string
{
    if (!$teeth) return '';
    $types = array_unique(array_map(static fn($t) => (int)substr($t, 1, 1), $teeth));
    $quads = array_unique(array_map(static fn($t) => (int)substr($t, 0, 1), $teeth));
    $upper = array_filter($teeth, static fn($t) => in_array($t[0], ['1', '2'], true));
    $lower = array_filter($teeth, static fn($t) => in_array($t[0], ['3', '4'], true));
    if (count($teeth) === 32) return 'Full mouth, both arches';
    if (count($upper) === 16 && !$lower) return 'Full upper arch';
    if (count($lower) === 16 && !$upper) return 'Full lower arch';
    if (count($types) === 1) {
        $name = ['', 'Central incisors', 'Lateral incisors', 'Canines', 'First premolars', 'Second premolars', 'First molars', 'Second molars', 'Third molars'][reset($types)] ?? 'Teeth';
        if (count($teeth) === 1) return ucfirst(sd_tooth_long_name(reset($teeth)));
        $where = count($quads) === 4 ? 'all four quadrants' : (!$lower ? 'upper arch' : (!$upper ? 'lower arch' : count($quads) . ' quadrants'));
        return $name . ', ' . $where;
    }
    return count($teeth) . ' teeth, ' . (!$lower ? 'upper arch' : (!$upper ? 'lower arch' : 'both arches'));
}

/** Readable service name for one restoration record, e.g. "3-Unit Bridge (35–37)" or "Complete Denture (Upper)". */
function sd_restoration_service(array $o): string
{
    $teeth = sd_json_list($o['selected_teeth'] ?? '[]');
    $work = sd_json_list($o['work_options'] ?? '[]');
    if (($o['restoration_type'] ?? '') === 'removable') {
        $name = $work[0] ?? 'Removable Denture';
        $upper = (bool)array_filter($teeth, static fn($t) => in_array($t[0], ['1', '2'], true));
        $lower = (bool)array_filter($teeth, static fn($t) => in_array($t[0], ['3', '4'], true));
        $arch = $upper && $lower ? 'Upper & Lower' : ($upper ? 'Upper' : ($lower ? 'Lower' : ''));
        return $name . ($arch !== '' ? ' (' . $arch . ')' : '');
    }
    $material = $work ? implode(' / ', $work) . ' ' : '';
    if (!$teeth) return trim($material . 'Fixed Restoration');
    // Adjacent teeth in one quadrant are a bridge, single teeth are crowns.
    $byQuad = [];
    foreach ($teeth as $t) $byQuad[$t[0]][] = (int)$t[1];
    if (count($byQuad) === 1 && count($teeth) >= 2) {
        $q = array_key_first($byQuad);
        $n = $byQuad[$q];
        sort($n);
        if (max($n) - min($n) === count($n) - 1) return $material . count($n) . '-Unit Bridge (' . $q . min($n) . '–' . $q . max($n) . ')';
    }
    return $material . (count($teeth) === 1 ? 'Crown' : 'Crowns') . ' (' . implode(', ', $teeth) . ')';
}

/** Stage of a restoration record: the removable stages chosen, otherwise the order status. */
function sd_restoration_stage(array $o): string
{
    if (($o['restoration_type'] ?? '') === 'removable') {
        $work = sd_json_list($o['work_options'] ?? '[]');
        $stages = array_slice($work, 1);
        if ($stages) return implode(', ', $stages);
    }
    return (string)($o['status'] ?? 'Draft');
}

function sd_status_class(string $status): string
{
    return strtolower(str_replace([' ', '_'], '-', trim($status)));
}

function sd_initials(string $first, string $last = ''): string
{
    $i = mb_strtoupper(mb_substr(trim($first), 0, 1) . mb_substr(trim($last), 0, 1));
    return $i !== '' ? $i : 'P';
}

/** Date + time label for an appointment-like row. */
function sd_date_time_cell(?string $date, ?string $time = null): string
{
    if (!$date) return '<b>—</b>';
    $html = '<b>' . e(date('M d, Y', strtotime($date))) . '</b>';
    if ($time !== null && $time !== '') $html .= '<small>' . e(date('h:i A', strtotime($time))) . '</small>';
    return $html;
}

/** Treatment plans of a patient with how many removable / fixed records each one has. */
function sd_patient_treatment_plans(mysqli $conn, int $patientId): array
{
    $st = $conn->prepare("SELECT tp.id,tp.procedure_name,tp.status,tp.created_at,tp.updated_at,CONCAT(d.first_name,' ',d.last_name) dentist_name,
            (SELECT COUNT(*) FROM restoration_orders r WHERE r.treatment_plan_id=tp.id AND r.restoration_type='removable') removable_count,
            (SELECT COUNT(*) FROM restoration_orders r WHERE r.treatment_plan_id=tp.id AND r.restoration_type='fixed') fixed_count,
            (SELECT MIN(r.id) FROM restoration_orders r WHERE r.treatment_plan_id=tp.id AND r.restoration_type='removable') removable_first,
            (SELECT MIN(r.id) FROM restoration_orders r WHERE r.treatment_plan_id=tp.id AND r.restoration_type='fixed') fixed_first
        FROM treatment_plans tp LEFT JOIN users d ON d.id=tp.dentist_id WHERE tp.patient_id=? ORDER BY tp.created_at DESC, tp.id DESC");
    if (!$st) return [];
    $st->bind_param('i', $patientId);
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
    return $rows;
}

/** Restoration records of one type under a treatment plan (newest first). */
function sd_plan_restorations(mysqli $conn, int $planId, string $type, int $patientId): array
{
    $st = $conn->prepare("SELECT ro.*,CONCAT(d.first_name,' ',d.last_name) dentist_name FROM restoration_orders ro LEFT JOIN users d ON d.id=ro.dentist_id WHERE ro.treatment_plan_id=? AND ro.restoration_type=? AND ro.patient_id=? ORDER BY COALESCE(ro.date_sent,DATE(ro.created_at)) DESC, ro.id DESC");
    if (!$st) return [];
    $st->bind_param('isi', $planId, $type, $patientId);
    $st->execute();
    $rows = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    $st->close();
    return $rows;
}

/** Keeps a treatment plan's status in step with the restoration records inside it. */
function sd_refresh_plan_status(mysqli $conn, int $planId): void
{
    if ($planId < 1) return;
    $st = $conn->prepare("SELECT COUNT(*) total, SUM(status='Completed') done, SUM(status='Cancelled') cancelled, SUM(status IN ('Sent','In Progress','Ready')) active FROM restoration_orders WHERE treatment_plan_id=?");
    $st->bind_param('i', $planId);
    $st->execute();
    $c = $st->get_result()->fetch_assoc();
    $st->close();
    $total = (int)($c['total'] ?? 0);
    if (!$total) return;
    $status = (int)$c['cancelled'] === $total ? 'Cancelled' : ((int)$c['done'] + (int)$c['cancelled'] === $total ? 'Completed' : ((int)$c['active'] > 0 || (int)$c['done'] > 0 ? 'In Progress' : 'Proposed'));
    $st = $conn->prepare('UPDATE treatment_plans SET status=? WHERE id=?');
    $st->bind_param('si', $status, $planId);
    $st->execute();
    $st->close();
}

/** Service, date and time for a dental chart (stored values first, then that day's appointment). */
function sd_chart_meta(mysqli $conn, array $chart): array
{
    $date = $chart['chart_date'] ?: date('Y-m-d', strtotime((string)$chart['created_at']));
    $service = trim((string)($chart['service'] ?? ''));
    $time = $chart['chart_time'] ?? null;
    if ($service === '' || !$time) {
        $st = $conn->prepare("SELECT appointment_type, appointment_time FROM appointments WHERE patient_id=? AND appointment_date=? AND status IN ('approved','completed') ORDER BY appointment_time LIMIT 1");
        $pid = (int)$chart['patient_id'];
        $st->bind_param('is', $pid, $date);
        $st->execute();
        $a = $st->get_result()->fetch_assoc();
        $st->close();
        if ($service === '') $service = (string)($a['appointment_type'] ?? '');
        if (!$time) $time = $a['appointment_time'] ?? date('H:i:s', strtotime((string)$chart['created_at']));
    }
    return ['date' => $date, 'time' => $time, 'service' => $service !== '' ? $service : 'Dental Examination'];
}

function sd_load_patient(mysqli $conn, int $patientId): ?array
{
    $st = $conn->prepare("SELECT u.id,u.first_name,u.last_name,u.email,u.status,u.created_at,u.patient_no,p.phone,p.birthday,p.gender,p.address FROM users u LEFT JOIN patient_profiles p ON p.user_id=u.id WHERE u.id=? AND u.role='patient' LIMIT 1");
    $st->bind_param('i', $patientId);
    $st->execute();
    $p = $st->get_result()->fetch_assoc();
    $st->close();
    if ($p) $p['code'] = sd_patient_code($p['patient_no'], $p['id']);
    return $p ?: null;
}

/** Patient banner: initials, name, patient number, email, registration date and a Back button. */
function sd_render_patient_card(array $p, string $backUrl = '', bool $privacyBadge = true): void
{
    ?>
<section class="r3-patient-card">
  <span class="r3-avatar"><?= e(sd_initials($p['first_name'], $p['last_name'])) ?></span>
  <div class="r3-patient-id"><b><?= e($p['first_name'] . ' ' . $p['last_name']) ?></b><small>Patient ID #<?= e($p['code']) ?> · <?= e($p['email']) ?> · Registered <?= e(date('M d, Y', strtotime($p['created_at']))) ?></small></div>
  <?php if ($privacyBadge): ?><span class="r3-privacy"><i class="fa-solid fa-lock"></i> Showing records of Patient #<?= e($p['code']) ?> only</span><?php endif; ?>
  <?php if ($backUrl !== ''): ?><a class="r3-back" href="<?= e($backUrl) ?>"><i class="fa-solid fa-arrow-left"></i> Back</a><?php endif; ?>
</section>
    <?php
}
