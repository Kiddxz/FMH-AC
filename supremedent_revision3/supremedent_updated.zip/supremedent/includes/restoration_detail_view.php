<?php
/**
 * Read-only Removable / Fixed Restoration Plan (revision 3), printable to PDF.
 * Used by the patient (Treatment History), the assistant and the dentist (patient records, Treatment Plans).
 */
require_once __DIR__ . '/record_helpers.php';
require_once __DIR__ . '/restoration_options.php';

/** Loads one restoration order. $where: ['patient_id' => n] and/or ['dentist_id' => n] limit what can be opened. */
function sd_load_restoration(mysqli $conn, int $id, array $where = []): ?array
{
    $sql = "SELECT ro.*, p.first_name patient_first, p.last_name patient_last, p.patient_no, CONCAT(d.first_name,' ',d.last_name) dentist_name,
            CONCAT(c.first_name,' ',c.last_name) creator_name, tp.procedure_name plan_name, tp.created_at plan_created
        FROM restoration_orders ro JOIN users p ON p.id=ro.patient_id LEFT JOIN users d ON d.id=ro.dentist_id
        LEFT JOIN users c ON c.id=COALESCE(ro.created_by, ro.dentist_id) LEFT JOIN treatment_plans tp ON tp.id=ro.treatment_plan_id WHERE ro.id=?";
    $types = 'i';
    $params = [$id];
    foreach (['patient_id', 'dentist_id'] as $col) {
        if (isset($where[$col])) { $sql .= " AND ro.$col=?"; $types .= 'i'; $params[] = (int)$where[$col]; }
    }
    $st = $conn->prepare($sql . ' LIMIT 1');
    $st->bind_param($types, ...$params);
    $st->execute();
    $o = $st->get_result()->fetch_assoc();
    $st->close();
    return $o ?: null;
}

/**
 * Renders the plan. $opts: back (url), edit (url|''), crumbs (html|''), eyebrowPrefix.
 * Call sd_restoration_detail_scripts() once after it.
 */
function sd_render_restoration_detail(array $o, array $opts = []): void
{
    $rx = sd_rx_options();
    $type = $o['restoration_type'] === 'fixed' ? 'fixed' : 'removable';
    $teeth = array_values(array_intersect(array_merge(SD_FDI_UPPER, SD_FDI_LOWER), sd_json_list($o['selected_teeth'])));
    $work = sd_json_list($o['work_options']);
    $materials = sd_json_list($o['teeth_material_options']);
    $stain = sd_json_list($o['staining_options']);
    $metal = sd_design_list($o['metal_design']);
    $pontic = sd_design_list($o['pontic_design']);
    $patientName = trim($o['patient_first'] . ' ' . $o['patient_last']);
    $title = ucfirst($type) . ' Restoration Plan';
    $sent = $o['date_sent'] ? strtotime($o['date_sent']) : null;
    $due = $o['date_due'] ? strtotime($o['date_due']) : null;
    $days = $sent && $due ? (int)round(($due - $sent) / 86400) : null;
    $notProvided = '<span class="r3-dash">Not provided</span>';
    $val = static fn($v) => trim((string)$v) !== '' ? e($v) : '<span class="r3-dash">Not provided</span>';
    $box = static fn(string $label, bool $on, string $cls = '') => '<span class="r3-rx-check' . ($on ? ' on' : '') . ($cls ? ' ' . $cls : '') . '"><i class="r3-rx-box">' . ($on ? '&#10003;' : '') . '</i>' . e($label) . '</span>';
    $occlusal = ''; $trans = '';
    foreach ($stain as $sv) {
        if (str_starts_with($sv, 'Staining: ')) $occlusal = substr($sv, 10);
        if (str_starts_with($sv, 'Translucency: ')) $trans = substr($sv, 14);
    }
    $fileName = 'SupremeDent-' . ucfirst($type) . '-Plan-' . preg_replace('/[^A-Za-z0-9_-]+/', '', (string)($o['order_no'] ?: $o['id']));
    ?>
<div class="r3-plan-page" id="restorationPlan" data-print-title="<?= e($fileName) ?>">
<?php if (!empty($opts['crumbs'])): ?><nav class="r3-crumbs r3-no-print"><?= $opts['crumbs'] ?></nav><?php endif; ?>
<div class="r3-plan-head">
  <div><span class="r3-eyebrow"><?= e(strtoupper($type)) ?> RESTORATION</span><h1><?= e($title) ?></h1><p class="muted"><?= e($patientName) ?> · Order No. <?= e($o['order_no'] ?: '—') ?></p></div>
  <div class="r3-plan-actions r3-no-print">
    <?php if (!empty($opts['back'])): ?><a class="r3-back" href="<?= e($opts['back']) ?>"><i class="fa-solid fa-arrow-left"></i> Back</a><?php endif; ?>
    <?php if (!empty($opts['edit'])): ?><a class="r3-back" href="<?= e($opts['edit']) ?>"><i class="fa-solid fa-pen"></i> Edit</a><?php endif; ?>
    <button type="button" class="r3-btn-solid r3-print-btn" data-print-plan><i class="fa-solid fa-print"></i> Print</button>
  </div>
</div>
<section class="r3-card r3-plan-summary">
  <div class="r3-ps-patient"><span class="r3-avatar sm"><?= e(sd_initials($o['patient_first'], $o['patient_last'])) ?></span><div><span>Patient</span><b><?= e($patientName) ?></b></div></div>
  <div><span>Dentist</span><b><?= e($o['dentist_name'] ?: '—') ?></b></div>
  <div><span>Order No.</span><b><?= e($o['order_no'] ?: '—') ?></b></div>
  <div><span>Date sent → Date due</span><b><?= $sent ? e(date('M d, Y', $sent)) : '—' ?> → <?= $due ? e(date('M d, Y', $due)) : '—' ?><?= $days !== null && $days >= 0 ? ' <small>(' . $days . ' day' . ($days === 1 ? '' : 's') . ')</small>' : '' ?></b><?php if ($days !== null && $days < 0): ?><em class="r3-warn"><i class="fa-solid fa-triangle-exclamation"></i> Due date is before date sent</em><?php endif; ?></div>
  <div><span>Status</span><b><span class="status-pill r3-st-<?= e(sd_status_class($o['status'])) ?>"><?= e($o['status']) ?></span></b></div>
</section>
<div class="r3-plan-grid">
  <div class="r3-plan-col">
    <section class="r3-card">
      <h2 class="r3-title">Patient Information</h2>
      <div class="r3-info-grid"><div><span>Phone</span><b><?= $val($o['phone']) ?></b></div><div><span>Sex</span><b><?= $val($o['sex']) ?></b></div><div><span>Age</span><b><?= $val($o['age']) ?></b></div></div>
    </section>
    <section class="r3-card">
      <h2 class="r3-title">Lab Prescription</h2>
      <?php if ($type === 'removable'):
          $current = '';
          foreach ($work as $w) if (isset($rx['removableWork'][$w])) { $current = $w; break; }
          $stages = $current ? $rx['removableWork'][$current][1] : []; ?>
        <div class="r3-rx-label">1 · Type of Work</div>
        <div class="r3-work-cards"><?php foreach ($rx['removableWork'] as $w => [$desc]): ?><div class="r3-work-card<?= $w === $current ? ' on' : '' ?>"><b><?= e($w) ?></b><small><?= e($desc) ?></small></div><?php endforeach; ?></div>
        <div class="r3-rx-panel"><div class="r3-rx-label">2 · Stage for <?= e($current ?: 'type of work') ?></div><div class="r3-rx-row"><?php foreach ($stages as $sg) echo $box($sg, in_array($sg, $work, true)); if (!$stages) echo '<span class="r3-dash">No stage selected</span>'; ?></div></div>
        <div class="r3-rx-label">3 · Type of Teeth</div>
        <div class="r3-rx-row"><?php foreach ($rx['teethTypes'] as $t) echo $box($t, in_array($t, $materials, true)); ?></div>
        <div class="r3-info-grid two"><div><span>Shade</span><b><?= e($o['shade'] ?: '—') ?></b></div><div><span>Mould</span><b><?= e($o['mould'] ?: '—') ?></b></div></div>
      <?php else: ?>
        <div class="r3-rx-label">Type of Work</div>
        <div class="r3-rx-row three"><?php foreach ($rx['fixedWork'] as $t) echo $box($t, in_array($t, $work, true)); ?></div>
        <div class="r3-rx-split">
          <div><div class="r3-rx-label">Type of Alloy</div><div class="r3-rx-row"><?php foreach ($rx['alloys'] as $t) echo $box($t, in_array($t, $materials, true)); ?></div><small class="muted">For PFM and Full Metal work.</small></div>
          <div><div class="r3-rx-label">Buccal Margin</div><div class="r3-rx-row stack"><?php foreach ($rx['margins'] as $t) echo $box($t, in_array($t, $materials, true)); ?></div></div>
        </div>
        <div class="r3-rx-label">Tooth to be Restored</div>
        <div class="r3-quad-view">
          <?php foreach (['Upper' => ['1', '2'], 'Lower' => ['4', '3']] as $arch => [$rq, $lq]): ?>
            <div class="r3-quad-row"><span><?= $arch ?></span><div><?php for ($n = 8; $n >= 1; $n--): $t = $rq . $n; ?><i class="<?= in_array($t, $teeth, true) ? 'on' : '' ?>" title="<?= e(sd_tooth_quadrant($t) . ' (tooth ' . $t . ')') ?>"><?= $n ?></i><?php endfor; ?><em></em><?php for ($n = 1; $n <= 8; $n++): $t = $lq . $n; ?><i class="<?= in_array($t, $teeth, true) ? 'on' : '' ?>" title="<?= e(sd_tooth_quadrant($t) . ' (tooth ' . $t . ')') ?>"><?= $n ?></i><?php endfor; ?></div></div>
          <?php endforeach; ?>
          <div class="r3-sides"><span>Patient's right</span><span>Patient's left</span></div>
        </div>
        <div class="r3-tooth-tags"><?php foreach ($teeth as $t): ?><span><b>Tooth <?= e($t) ?></b> · <?= e(sd_tooth_quadrant($t)) ?> · <?= e(sd_tooth_long_name($t)) ?></span><?php endforeach; if (!$teeth): ?><span class="r3-dash">No tooth selected</span><?php endif; ?></div>
      <?php endif; ?>
    </section>
    <section class="r3-card">
      <h2 class="r3-title">Instructions</h2>
      <div class="r3-instructions"><?= trim((string)$o['instructions']) !== '' ? nl2br(e($o['instructions'])) : '<span class="r3-dash">No additional instructions.</span>' ?></div>
    </section>
  </div>
  <div class="r3-plan-col">
    <?php if ($type === 'removable'): ?>
    <section class="r3-card">
      <div class="r3-card-head"><div><h2 class="r3-title">3D Model</h2><p class="muted">Highlighted teeth are marked for replacement.</p></div><b class="r3-teeth-count"><?= count($teeth) ?> <?= count($teeth) === 1 ? 'tooth' : 'teeth' ?> to replace</b></div>
      <div class="r3-arch-stage r3-print-3d" id="planArchModel" data-teeth="<?= e(json_encode($teeth)) ?>"><span>Loading 3D model...</span></div>
      <div class="r3-rx-label r3-mt">Teeth to Replace</div>
      <div class="r3-fdi-view"><?php foreach ([SD_FDI_UPPER, SD_FDI_LOWER] as $row): ?><div><?php foreach ($row as $t): ?><i class="<?= in_array($t, $teeth, true) ? 'on' : '' ?>"><?= $t ?></i><?php endforeach; ?></div><?php endforeach; ?></div>
      <div class="r3-sides"><span>Patient's right</span><span>Patient's left</span></div>
      <div class="r3-tooth-tags"><?php foreach ($teeth as $t): ?><span><b><?= e($t) ?></b> · <?= e(sd_tooth_quadrant($t)) ?></span><?php endforeach; ?><?php if ($teeth): ?><span class="r3-summary-tag"><?= e(sd_teeth_summary($teeth)) ?></span><?php endif; ?></div>
    </section>
    <?php else: ?>
    <section class="r3-card">
      <h2 class="r3-title">Staining &amp; Design</h2>
      <div class="r3-rx-label">Chart for Staining</div>
      <div class="r3-stain-stage r3-print-3d" id="planStainModel"><span>Loading staining chart...</span></div>
      <div class="r3-rx-label r3-mt">Shade</div>
      <div class="r3-shade"><i style="background: <?= e(sd_shade_color((string)$o['shade'])) ?>"></i><div><b><?= e($o['shade'] ?: 'No shade') ?></b><small>VITA classical shade</small></div></div>
      <div class="r3-rx-split">
        <div><div class="r3-rx-label">Occlusal Staining</div><div class="r3-seg"><?php foreach ($rx['occlusal'] as $x): ?><span class="<?= $occlusal === $x ? 'on' : '' ?>"><?= e($x) ?></span><?php endforeach; ?></div></div>
        <div><div class="r3-rx-label">Translucency</div><div class="r3-seg"><?php foreach ($rx['translucency'] as $x): ?><span class="<?= $trans === $x ? 'on' : '' ?>"><?= e($x) ?></span><?php endforeach; ?></div></div>
      </div>
      <div class="r3-rx-split">
        <div><div class="r3-rx-label">Metal Design</div><?php if (!$metal): ?><p class="r3-dash">No metal design selected</p><?php endif; ?><?php foreach ($metal as $m): $def = $rx['metalDesigns'][$m] ?? null; ?><div class="r3-design-pick"><span class="r3-design-img"><?php if ($def): ?><img alt="" data-model="<?= e($def[0]) ?>" data-nodes="<?= e(json_encode($def[1])) ?>"><?php endif; ?></span><div><small>Selected</small><b><?= e($m) ?></b><em>Metal design</em></div></div><?php endforeach; ?></div>
        <div><div class="r3-rx-label">Pontic Design</div><?php if (!$pontic): ?><p class="r3-dash">No pontic design selected</p><?php endif; ?><?php foreach ($pontic as $m): $def = $rx['ponticDesigns'][$m] ?? null; ?><div class="r3-design-pick"><span class="r3-design-img"><?php if ($def): ?><img alt="" data-model="P.glb" data-nodes="<?= e(json_encode($def[1])) ?>"><?php endif; ?></span><div><small>Selected</small><b><?= e($m) ?></b><em>Pontic design</em></div></div><?php endforeach; ?></div>
      </div>
    </section>
    <?php endif; ?>
    <section class="r3-card r3-created">
      <div><span>Created</span><b><?= e(date('M d, Y', strtotime($o['created_at']))) ?> · by <?= e($o['creator_name'] ?: ($o['dentist_name'] ?: 'Clinic staff')) ?></b></div>
      <div class="right"><span>Last updated</span><b><?= e(date('M d, Y · g:i A', strtotime($o['updated_at'] ?: $o['created_at']))) ?></b></div>
    </section>
  </div>
</div>
</div>
    <?php
}

function sd_restoration_detail_scripts(): void
{
    ?>
<script type="importmap">{"imports":{"three":"../assets/js/three.module.js"}}</script>
<script type="module">
import { createArchViewer, createStainingViewer, renderDesignThumbnails } from '../assets/js/restoration_3d.js';
const arch = document.getElementById('planArchModel');
if (arch) createArchViewer(arch, { selected: new Set(JSON.parse(arch.dataset.teeth || '[]')), readOnly: true, pickColor: 0x2676db });
const stain = document.getElementById('planStainModel');
if (stain) createStainingViewer(stain);
const imgs = [...document.querySelectorAll('.r3-design-img img')];
if (imgs.length) renderDesignThumbnails(imgs.map(img => ({ model: img.dataset.model, nodes: JSON.parse(img.dataset.nodes), img })));
</script>
<script>
(() => {
    // Print / Save as PDF: the 3D views are copied into pictures so they appear on paper.
    const plan = document.getElementById('restorationPlan');
    function snapshot() {
        document.querySelectorAll('.r3-print-3d canvas').forEach(c => {
            try { const img = new Image(); img.className = 'r3-print-snap'; img.src = c.toDataURL('image/png'); c.after(img); } catch (_) {}
        });
    }
    const clear = () => document.querySelectorAll('.r3-print-snap').forEach(i => i.remove());
    window.addEventListener('beforeprint', () => { clear(); snapshot(); });
    window.addEventListener('afterprint', clear);
    document.querySelectorAll('[data-print-plan]').forEach(b => b.addEventListener('click', () => {
        const old = document.title;
        document.title = plan?.dataset.printTitle || old;
        clear(); snapshot();
        window.print();
        setTimeout(() => { document.title = old; clear(); }, 800);
    }));
})();
</script>
    <?php
}
