<?php
/** Lab prescription options for removable / fixed restoration plans (shared by the form and the views). */

function sd_rx_options(): array
{
    return [
        'removableWork' => [
            'Complete Denture' => ['Full arch', ['Bite Block', 'Setup for Try-In', 'Process & Finish', 'Custom Tray']],
            'Cast Partial Framework' => ['Metal framework', ['Frame Try-In', 'Frame w/ Bite Block', 'Frame w/ Teeth Try-In', 'Process & Finish']],
            'Combo Partial' => ['Cast frame & thermoplastic w/ colored clamp', ['Frame Try-In', 'Frame w/ Teeth Try-In', 'Process & Finish']],
            'Flexible' => ['Flexible partial', ['Bite Block', 'Setup for Try-In', 'Process & Finish']],
            'Acrylic Partials' => ['Acrylic base', ['Bite Block', 'Setup for Try-In', 'Process & Finish']],
        ],
        'teethTypes' => ['Plastic', 'Porcelain', 'Ivoclar', 'Bioform', 'New Ace PX'],
        'fixedWork' => ['Zircon', 'Pressed Ceramic', 'Ceramage', 'Plastic', 'Full Metal', 'PFM'],
        'alloys' => ['Non-Precious', 'Tilite'],
        'margins' => ['Porcelain Butt Margin', 'Metal Margin on Buccal', 'Metal-Porcelain Junction Margin'],
        'occlusal' => ['None', 'Light', 'Medium', 'Dark'],
        'translucency' => ['Low', 'Medium', 'High'],
        // Metal designs: M1.glb Design 1-4, M2.glb Design 5-9 (mesh names from the 3D files).
        'metalDesigns' => [
            'Design 1' => ['M1.glb', ['Molar_A_Clean']], 'Design 2' => ['M1.glb', ['Molar_B_Thin_Band']], 'Design 3' => ['M1.glb', ['Molar_C_Wide_Band']], 'Design 4' => ['M1.glb', ['Molar_D_Corner']],
            'Design 5' => ['M2.glb', ['Molar_A_Side_Region']], 'Design 6' => ['M2.glb', ['Molar_B_Large_Side_Region']], 'Design 7' => ['M2.glb', ['Incisor_C_Clean']],
            'Design 8' => ['M2.glb', ['Incisor_D_Edge_Region']], 'Design 9' => ['M2.glb', ['Incisor_E_Deep_Region']],
        ],
        // Pontic designs: P.glb tooth + its dark base.
        'ponticDesigns' => [
            'Hygienic' => ['Hygienic', ['Tooth_A_Peak', 'Tooth_A_Peak_DarkBase']],
            'Modified Ridge Lap' => ['Modified RL', ['Tooth_B_Wedge', 'Tooth_B_Wedge_DarkBase']],
            'Bullet' => ['Bullet', ['Tooth_C_Flat', 'Tooth_C_Flat_DarkBase']],
            'Ridge Lap' => ['Ridge Lap', ['Tooth_D_Mound', 'Tooth_D_Mound_DarkBase']],
        ],
        'statuses' => ['Draft', 'Sent', 'In Progress', 'Ready', 'Completed', 'Cancelled'],
    ];
}

/** Approximate swatch color for a VITA classical shade name. */
function sd_shade_color(string $shade): string
{
    $map = ['A1' => '#f4e8d0', 'A2' => '#eedcb8', 'A3' => '#e7cfa2', 'A3.5' => '#e0c391', 'A4' => '#d6b47c', 'B1' => '#f6eed8', 'B2' => '#efdfbd', 'B3' => '#e6cf9f', 'B4' => '#dcc08b',
        'C1' => '#e8dcc2', 'C2' => '#dfcfae', 'C3' => '#d3c09b', 'C4' => '#c5ae86', 'D2' => '#e9dcc4', 'D3' => '#dfcfb0', 'D4' => '#d8c6a4'];
    $key = strtoupper(preg_replace('/[^A-Da-d0-9.]/', '', explode(',', $shade)[0]));
    return $map[$key] ?? '#eadfc8';
}
