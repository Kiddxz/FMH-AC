<?php
/**
 * Staff view of one restoration plan (dentist and assistant), opened from Treatment Plans.
 * Expects $viewRole ('dentist'|'assistant'). Dentists can open any plan but edit only their own.
 */
require_once __DIR__ . '/restoration_detail_view.php';
$viewRole = ($viewRole ?? '') === 'assistant' ? 'assistant' : 'dentist';
$uid = (int)$_SESSION['user_id'];
$o = sd_load_restoration($conn, (int)($_GET['id'] ?? 0));
if (!$o) { header('Location: treatment_plans.php'); exit; }
$canEdit = $viewRole === 'assistant' || (int)$o['dentist_id'] === $uid;
$back = (int)($_GET['patient'] ?? 0) > 0 ? 'patient_record.php?id=' . (int)$o['patient_id'] . '&tab=plans' : 'treatment_plans.php';
require __DIR__ . '/ui.php';
ui_header(ucfirst($o['restoration_type']) . ' Restoration Plan', $viewRole);
ui_sidebar($viewRole, 'treatment_plans.php');
if (isset($_GET['saved'])) flash('success', 'Treatment plan saved.');
sd_render_restoration_detail($o, ['back' => $back, 'edit' => $canEdit ? 'restoration_form.php?id=' . (int)$o['id'] : '']);
sd_restoration_detail_scripts();
ui_footer();
