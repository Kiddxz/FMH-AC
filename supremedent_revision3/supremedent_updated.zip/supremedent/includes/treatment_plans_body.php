<?php
/**
 * Restoration Treatment Plans page, shared by the dentist and assistant portals (revision 3).
 * Dentists see the plans under their name; the assistant sees every plan.
 * Expects $plansRole ('dentist'|'assistant').
 */
require_once __DIR__ . '/record_helpers.php';
$plansRole = ($plansRole ?? '') === 'assistant' ? 'assistant' : 'dentist';
$uid = (int)$_SESSION['user_id'];
$q = trim($_GET['q'] ?? '');
$sql = "SELECT ro.*,CONCAT(u.first_name,' ',u.last_name) patient_name,CONCAT(d.first_name,' ',d.last_name) dentist_name,tp.procedure_name plan_name FROM restoration_orders ro JOIN users u ON u.id=ro.patient_id LEFT JOIN users d ON d.id=ro.dentist_id LEFT JOIN treatment_plans tp ON tp.id=ro.treatment_plan_id WHERE 1=1";
$params = [];
$types = '';
if ($plansRole === 'dentist') { $sql .= ' AND ro.dentist_id=?'; $params[] = $uid; $types .= 'i'; }
if ($q !== '') {
    $sql .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR CONCAT(u.first_name,' ',u.last_name) LIKE ? OR u.email LIKE ? OR ro.order_no LIKE ? OR ro.restoration_type LIKE ? OR ro.status LIKE ? OR tp.procedure_name LIKE ?)";
    $like = '%' . $q . '%';
    $params = array_merge($params, array_fill(0, 8, $like));
    $types .= str_repeat('s', 8);
}
$sql .= ' ORDER BY ro.created_at DESC, ro.id DESC';
$st = $conn->prepare($sql);
if ($types) $st->bind_param($types, ...$params);
$st->execute();
$orders = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$st->close();
require __DIR__ . '/ui.php';
ui_header('Treatment Plans', $plansRole);
ui_sidebar($plansRole, 'treatment_plans.php'); ?>
<div class="page-head compact-head"><div><div class="eyebrow">TREATMENT PLANS</div><h1>Restoration Treatment Plans</h1><div class="muted">Create a removable or fixed restoration order, then review previous plans below.</div></div></div>
<section class="plan-chooser">
    <a class="plan-choice" href="restoration_form.php?type=removable"><div><h2>Removable Restoration</h2><p>Complete denture, partial denture, bite block, try-in, materials, shade, mould, instructions, and interactive tooth selection.</p></div><span><i class="fa-solid fa-plus"></i> Create Plan</span></a>
    <a class="plan-choice" href="restoration_form.php?type=fixed"><div><h2>Fixed Restoration</h2><p>Zircon, ceramic, PFM, alloy, buccal margin, staining, metal/pontic design, instructions, and interactive tooth selection.</p></div><span><i class="fa-solid fa-plus"></i> Create Plan</span></a>
</section>
<section class="r3-card" data-live-region="plans">
    <div class="r3-card-head"><div><h2>Treatment Plan History</h2><p class="muted">Search by patient, order number, type, or status.</p></div><span class="r3-count"><?= count($orders) ?> plan<?= count($orders) === 1 ? '' : 's' ?></span></div>
    <form class="directory-search r3-search" method="get"><input name="q" type="search" value="<?= e($q) ?>" placeholder="Search treatment history"><button class="btn btn-primary">Search</button><?php if ($q !== ''): ?><a class="btn btn-secondary" href="treatment_plans.php">Clear</a><?php endif; ?></form>
    <div class="r3-table-scroll" style="--r3-rows-height: 470px">
    <table class="r3-table"><thead><tr><th>Date</th><th>Order No.</th><th>Patient</th><th>Restoration</th><th>Selected Teeth</th><th>Status</th><?php if ($plansRole === 'assistant'): ?><th>Dentist</th><?php endif; ?><th class="r3-actions-col">Action</th></tr></thead><tbody>
    <?php foreach ($orders as $o): $teeth = sd_json_list($o['selected_teeth']); ?>
        <tr><td><?= e(date('M d, Y', strtotime($o['date_sent'] ?: $o['created_at']))) ?></td><td><?= e($o['order_no'] ?: '—') ?></td><td><b><?= e($o['patient_name']) ?></b><?php if ($o['plan_name']): ?><small><?= e($o['plan_name']) ?></small><?php endif; ?></td><td><?= e(ucfirst($o['restoration_type'])) ?></td><td><?= e($teeth ? implode(', ', $teeth) : '—') ?></td><td><span class="status-pill r3-st-<?= e(sd_status_class($o['status'])) ?>"><?= e($o['status']) ?></span></td><?php if ($plansRole === 'assistant'): ?><td><?= e($o['dentist_name'] ?: '—') ?></td><?php endif; ?><td class="r3-actions"><div><a class="r3-btn-view" href="restoration_view.php?id=<?= (int)$o['id'] ?>">View</a><a class="r3-btn-view" href="restoration_form.php?id=<?= (int)$o['id'] ?>">Edit</a></div></td></tr>
    <?php endforeach; if (!$orders): ?><tr><td colspan="<?= $plansRole === 'assistant' ? 8 : 7 ?>" class="empty">No restoration treatment plans found.</td></tr><?php endif; ?>
    </tbody></table>
    </div>
</section>
<?php ui_footer(); ?>
