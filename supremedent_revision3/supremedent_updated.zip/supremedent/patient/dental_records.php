<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'patient', false);
require_once __DIR__ . '/../includes/chart_detail_view.php';

$uid = (int) $_SESSION['user_id'];
$patient = sd_load_patient($conn, $uid);

// Revision 3: the dental record history lists every dental chart from the patient's visits (View opens the
// full chart). Older procedure-only records from the clinic are listed too and open in a small pop-up.
$rows = [];
foreach (sd_patient_charts($conn, $uid) as $c) {
    $rows[] = ['kind' => 'chart', 'id' => (int)$c['id'], 'date' => $c['meta']['date'], 'time' => $c['meta']['time'], 'service' => $c['meta']['service'], 'dentist' => sd_dr_name($c['dentist_name'])];
}
require_once '../includes/patient_record_visibility.php';
[$hidingEnabled, $hideWarning] = patient_record_visibility($conn, $uid);
$sql = 'SELECT d.id,d.record_date,d.procedure_name,d.diagnosis,d.dentist_name,d.notes,d.created_at FROM dental_records d';
$sql .= $hidingEnabled ? ' LEFT JOIN patient_hidden_records h ON h.record_id=d.id AND h.patient_id=? WHERE d.patient_id=? AND h.record_id IS NULL' : ' WHERE d.patient_id=?';
$st = $conn->prepare($sql);
if ($hidingEnabled) $st->bind_param('ii', $uid, $uid); else $st->bind_param('i', $uid);
$st->execute();
$legacy = [];
foreach ($st->get_result()->fetch_all(MYSQLI_ASSOC) as $r) {
    $legacy[(int)$r['id']] = ['date' => date('l, F j, Y', strtotime($r['record_date'])), 'service' => $r['procedure_name'], 'diagnosis' => $r['diagnosis'] ?: 'No diagnosis recorded', 'dentist' => $r['dentist_name'] ?: 'Not specified', 'notes' => $r['notes'] ?: 'No notes recorded.'];
    $rows[] = ['kind' => 'record', 'id' => (int)$r['id'], 'date' => $r['record_date'], 'time' => date('H:i:s', strtotime($r['created_at'])), 'service' => $r['procedure_name'], 'dentist' => $r['dentist_name'] ? sd_dr_name($r['dentist_name']) : 'Clinic staff'];
}
$st->close();
usort($rows, static fn($a, $b) => [$b['date'], $b['time']] <=> [$a['date'], $a['time']]);
$latest = $rows[0] ?? null;
$first = $rows ? end($rows) : null;

require '../includes/ui.php';
ui_header('Dental Records', 'patient');
ui_sidebar('patient', 'dental_records.php'); ?>
<div class="page-head compact-head">
    <div>
        <div class="eyebrow">DENTAL RECORDS</div>
        <h1>My Dental Records</h1>
        <div class="muted">Your dental charts from every visit. Tap View to see the full chart.</div>
    </div>
</div>
<?php if ($hideWarning) flash('error', $hideWarning); ?>
<section class="r3-stats">
    <div class="r3-stat"><span class="r3-stat-icon"><i class="fa-regular fa-file-lines"></i></span><div><span>Dental records</span><b><?= count($rows) ?></b><small><?= $first ? 'Since ' . e(date('M Y', strtotime($first['date']))) : 'No records yet' ?></small></div></div>
    <div class="r3-stat"><span class="r3-stat-icon blue"><i class="fa-regular fa-calendar"></i></span><div><span>Latest record</span><b><?= $latest ? e(date('M d, Y', strtotime($latest['date']))) : 'None' ?></b><small><?= $latest ? e($latest['service']) : 'Records appear after your visit' ?></small></div></div>
    <div class="r3-stat"><span class="r3-stat-icon avatar"><?= e(sd_initials($patient['first_name'], $patient['last_name'])) ?></span><div><span>Patient</span><b><?= e($patient['first_name'] . ' ' . $patient['last_name']) ?></b><small>Patient ID #<?= e($patient['code']) ?></small></div></div>
</section>
<section class="r3-card" data-live-region="records">
    <div class="r3-card-head"><h2>Dental Record History</h2><span class="r3-count"><?= count($rows) ?> record<?= count($rows) === 1 ? '' : 's' ?></span></div>
    <div class="r3-table-scroll" style="--r3-rows-height: 440px">
        <table class="r3-table">
            <thead><tr><th>Date &amp; Time</th><th>Service</th><th>Dentist</th><th class="r3-actions-col">Actions</th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="4" class="empty">No dental records to display yet.</td></tr><?php endif; ?>
            <?php foreach ($rows as $i => $r): ?>
                <tr>
                    <td class="r3-date-cell"><b><?= e(date('M d, Y', strtotime($r['date']))) ?></b><?= $i === 0 ? '<span class="r3-latest">Latest</span>' : '' ?><small><?= $r['time'] ? e(date('h:i A', strtotime($r['time']))) : '' ?></small></td>
                    <td><?= e($r['service']) ?></td>
                    <td><?= e($r['dentist']) ?></td>
                    <td class="r3-actions"><?php if ($r['kind'] === 'chart'): ?><a class="r3-btn-view" href="record_view.php?id=<?= $r['id'] ?>">View</a><?php else: ?><button type="button" class="r3-btn-view" data-legacy="<?= $r['id'] ?>">View</button><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<div class="sd-modal" id="legacyModal" role="dialog" aria-modal="true" aria-labelledby="legacyTitle" aria-hidden="true">
    <div class="sd-modal-dialog sd-modal-small view-dialog">
        <button type="button" class="sd-modal-close" data-close-legacy aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
        <span class="profile-dialog-icon"><i class="fa-solid fa-file-medical"></i></span>
        <h2 id="legacyTitle">Dental Record</h2>
        <dl class="confirm-list" id="legacyList"></dl>
    </div>
</div>
<script>
(() => {
    const data = <?= json_encode((object)$legacy, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;
    const modal = document.getElementById('legacyModal'), list = document.getElementById('legacyList');
    const close = () => { modal.classList.remove('is-open'); modal.setAttribute('aria-hidden', 'true'); };
    document.querySelectorAll('[data-legacy]').forEach(b => b.addEventListener('click', () => {
        const r = data[b.dataset.legacy]; if (!r) return;
        list.replaceChildren();
        [['Date', r.date], ['Service', r.service], ['Diagnosis', r.diagnosis], ['Dentist', r.dentist], ['Notes', r.notes]].forEach(([k, v]) => { const dt = document.createElement('dt'); dt.textContent = k; const dd = document.createElement('dd'); dd.textContent = v; list.append(dt, dd); });
        modal.classList.add('is-open'); modal.setAttribute('aria-hidden', 'false');
    }));
    modal.querySelector('[data-close-legacy]').addEventListener('click', close);
    modal.addEventListener('click', e => { if (e.target === modal) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
})();
</script>
<?php ui_footer(); ?>
