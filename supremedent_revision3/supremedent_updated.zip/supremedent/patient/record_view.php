<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'patient', false);
require_once __DIR__ . '/../includes/chart_detail_view.php';

$uid = (int) $_SESSION['user_id'];
// Only the signed-in patient's own charts can be opened.
$chart = sd_load_chart($conn, (int)($_GET['id'] ?? 0), $uid);
if (!$chart) { header('Location: dental_records.php'); exit; }
$patient = sd_load_patient($conn, $uid);
require '../includes/ui.php';
ui_header('Dental Chart', 'patient');
ui_sidebar('patient', 'record_view.php'); ?>
<div class="page-head compact-head r3-tight-head">
    <div>
        <div class="eyebrow">DENTAL RECORDS</div>
        <h1>Dental Chart</h1>
        <div class="muted">Complete chart recorded on <?= e(date('M d, Y', strtotime($chart['meta']['date']))) ?>.</div>
    </div>
</div>
<div class="r3-stack">
<?php sd_render_patient_card($patient, 'dental_records.php'); ?>
<?php sd_render_chart_detail($chart); ?>
</div>
<?php sd_chart_detail_scripts(); ?>
<?php ui_footer(); ?>
