<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'patient', false);
require_once __DIR__ . '/../includes/restoration_detail_view.php';

$uid = (int) $_SESSION['user_id'];
// Patients can only open their own restoration records.
$o = sd_load_restoration($conn, (int)($_GET['id'] ?? 0), ['patient_id' => $uid]);
if (!$o) { header('Location: treatment_history.php'); exit; }
$siblings = $o['treatment_plan_id'] ? sd_plan_restorations($conn, (int)$o['treatment_plan_id'], $o['restoration_type'], $uid) : [];
$back = count($siblings) > 1 ? 'treatment_history.php?plan=' . (int)$o['treatment_plan_id'] . '&type=' . $o['restoration_type'] : 'treatment_history.php';
require '../includes/ui.php';
ui_header(ucfirst($o['restoration_type']) . ' Restoration Plan', 'patient');
ui_sidebar('patient', 'restoration_view.php');
sd_render_restoration_detail($o, ['back' => $back]);
sd_restoration_detail_scripts();
ui_footer();
