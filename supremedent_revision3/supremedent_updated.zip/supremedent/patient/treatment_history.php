<?php
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'patient', false);
require_once __DIR__ . '/../includes/record_helpers.php';

$uid = (int) $_SESSION['user_id'];
$patient = sd_load_patient($conn, $uid);
// Revision 3: Treatment History lists the patient's treatment plans. Each plan opens its Removable or Fixed
// restoration record (the separate Treatment Plans page was removed from the patient portal).
$plans = sd_patient_treatment_plans($conn, $uid);
$planId = (int)($_GET['plan'] ?? 0);
$type = ($_GET['type'] ?? '') === 'fixed' ? 'fixed' : 'removable';
$plan = null;
foreach ($plans as $p) if ((int)$p['id'] === $planId) $plan = $p;
$records = $plan ? sd_plan_restorations($conn, $planId, $type, $uid) : [];
if ($plan && count($records) === 1) { header('Location: restoration_view.php?id=' . (int)$records[0]['id']); exit; }
$latest = $plans[0] ?? null;
$first = $plans ? end($plans) : null;
$planLink = static function (array $p, string $type): string {
    $count = (int)$p[$type . '_count'];
    if ($count === 1) return 'restoration_view.php?id=' . (int)$p[$type . '_first'];
    return 'treatment_history.php?plan=' . (int)$p['id'] . '&type=' . $type;
};
require '../includes/ui.php';
ui_header('Treatment History', 'patient');
ui_sidebar('patient', 'treatment_history.php');
?>
<div class="page-head compact-head">
    <div>
        <div class="eyebrow">TREATMENT HISTORY</div>
        <h1><?= $plan ? e(ucfirst($type)) . ' Records' : 'My Treatment History' ?></h1>
        <div class="muted"><?= $plan ? 'All ' . e($type) . ' restoration records under the ' . e(date('M d, Y', strtotime($plan['created_at']))) . ' plan.' : 'Your treatment plans and their removable or fixed restoration records.' ?></div>
    </div>
</div>
<?php if (!$plan): ?>
<section class="r3-stats">
    <div class="r3-stat"><span class="r3-stat-icon"><i class="fa-regular fa-clipboard"></i></span><div><span>Total treatments</span><b><?= count($plans) ?></b><small><?= $first ? 'Since ' . e(date('M Y', strtotime($first['created_at']))) : 'No treatment plans yet' ?></small></div></div>
    <div class="r3-stat"><span class="r3-stat-icon blue"><i class="fa-regular fa-calendar"></i></span><div><span>Latest treatment</span><b><?= $latest ? e(date('M d, Y', strtotime($latest['created_at']))) : 'None' ?></b><small><?= $latest ? e($latest['procedure_name']) : 'Plans appear once your dentist adds one' ?></small></div></div>
    <div class="r3-stat"><span class="r3-stat-icon avatar"><?= e(sd_initials($patient['first_name'], $patient['last_name'])) ?></span><div><span>Patient</span><b><?= e($patient['first_name'] . ' ' . $patient['last_name']) ?></b><small>Patient ID #<?= e($patient['code']) ?></small></div></div>
</section>
<section class="r3-card" data-live-region="plans">
    <div class="r3-card-head"><h2>Treatment Records</h2><span class="r3-count"><?= count($plans) ?> record<?= count($plans) === 1 ? '' : 's' ?></span></div>
    <div class="r3-table-scroll" style="--r3-rows-height: 440px">
        <table class="r3-table">
            <thead><tr><th>Date &amp; Time</th><th>Service</th><th>Dentist</th><th class="r3-actions-col">Actions</th></tr></thead>
            <tbody>
            <?php if (!$plans): ?><tr><td colspan="4" class="empty">No treatment history to display yet.</td></tr><?php endif; ?>
            <?php foreach ($plans as $i => $p): ?>
                <tr>
                    <td class="r3-date-cell"><b><?= e(date('M d, Y', strtotime($p['created_at']))) ?></b><?= $i === 0 ? '<span class="r3-latest">Latest</span>' : '' ?><small><?= e(date('h:i A', strtotime($p['created_at']))) ?></small></td>
                    <td><?= e($p['procedure_name']) ?></td>
                    <td><?= e($p['dentist_name'] ? 'Dr. ' . $p['dentist_name'] : '—') ?></td>
                    <td class="r3-actions"><div>
                        <a class="r3-plan-btn removable<?= (int)$p['removable_count'] ? '' : ' is-empty' ?>" href="<?= e($planLink($p, 'removable')) ?>" title="<?= (int)$p['removable_count'] ? 'Open the removable restoration' : 'No removable restoration in this plan' ?>"><i class="fa-solid fa-teeth-open"></i> Removable</a>
                        <a class="r3-plan-btn fixed<?= (int)$p['fixed_count'] ? '' : ' is-empty' ?>" href="<?= e($planLink($p, 'fixed')) ?>" title="<?= (int)$p['fixed_count'] ? 'Open the fixed restoration' : 'No fixed restoration in this plan' ?>"><i class="fa-solid fa-tooth"></i> Fixed</a>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php else: ?>
<div class="r3-stack">
<?php sd_render_patient_card($patient, 'treatment_history.php', false); ?>
<section class="r3-card">
    <div class="r3-card-head"><h2><?= e(ucfirst($type)) ?> records</h2><span class="r3-count"><?= count($records) ?> record<?= count($records) === 1 ? '' : 's' ?></span></div>
    <table class="r3-table">
        <thead><tr><th>Date &amp; Time</th><th>Service</th><th>Stage</th><th class="r3-actions-col">Actions</th></tr></thead>
        <tbody>
        <?php if (!$records): ?><tr><td colspan="4" class="empty">No <?= e($type) ?> restoration in this plan yet.</td></tr><?php endif; ?>
        <?php foreach ($records as $r): ?>
            <tr><td class="r3-date-cell"><b><?= e(date('M d, Y', strtotime($r['date_sent'] ?: $r['created_at']))) ?></b><small><?= e(date('h:i A', strtotime($r['created_at']))) ?></small></td><td><?= e(sd_restoration_service($r)) ?></td><td><?= e(sd_restoration_stage($r)) ?></td><td class="r3-actions"><a class="r3-btn-view" href="restoration_view.php?id=<?= (int)$r['id'] ?>">View</a></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>
</div>
<?php endif; ?>
<?php ui_footer(); ?>
