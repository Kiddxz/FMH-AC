<?php
// Revision 3: Treatment Plans was removed from the patient portal. Treatment History shows every plan
// with its Removable and Fixed restoration records.
require_once __DIR__ . '/../config/security.php';
start_secure_session();
require_once __DIR__ . '/../config/database.php';
require_portal_role($conn, 'patient', false);
header('Location: treatment_history.php', true, 302);
exit;
